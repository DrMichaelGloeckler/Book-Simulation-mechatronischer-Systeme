% Parameter f�r die Aufgabe 7.2
% siehe: Aufgabe_7_2.slx

m = 2.0;        % Masse [kg]
r = 0.5;        % Radius [m]
mue_r = 1e-1;   % viskoser Reibkoeffizient [Nm.s/rad]
Mr0   = 0.0;    % Haftreibmoment [Nm]
g = 9.81;       % Erdbeschleunigung [m/s/s]

w0 = 0.0;       % Anfangswinkelgeschw. [rad/s]
alpha0 = 0.524; % Anfangswinkel [rad]
