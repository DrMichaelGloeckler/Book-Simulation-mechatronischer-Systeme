% Energiebilanz

if exist('tout','var')==0
    error('Die Simulation muss gelaufen sein.');
end
E_pot = m*g*yv;         % potenzielle Energie [J]
E_kin = m/2*v2;         % kinetische Energie [J]
E_ges = E_pot + E_kin;  % Gesamtenergie [J]

plot(tout,E_ges);
grid on; hold on;
plot(tout,E_pot,'k:');
plot(tout,E_kin,'k--');
xlabel('Zeit [s]');
ylabel('Energie [J]');
title('-gesamte/- -kinetische/...potenzielle Energie');
