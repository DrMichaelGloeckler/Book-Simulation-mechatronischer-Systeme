% Parameter f�r die Aufgabe 7.4
% siehe: schiefer_Wurf.mdl

% Fu�ball
m   = 0.50;      % m=0.5 kg
A   = pi*.125^2; % d=25 cm
v0  = 25;        % Anfangsgeschw. [m/s]
a0  = pi/4;      % Anfangswinkel [rad]
cw  = 0.35;
rho = 1.25;      % Dichte [kg/m3]
g   = 9.81;      % Erdbeschleunigung [m/s2]
