% Parameter f�r Aufgabe 7.1 
% siehe: exponentiellerProzess.slx

lambda = 0.5;
y0     = 1.0;
