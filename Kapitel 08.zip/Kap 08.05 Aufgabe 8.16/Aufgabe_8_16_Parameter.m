% DMS_parameter
R0 = 350.0;     % Widerstand [Ohm] in Ruhezustand ohne Dehnung
k  = 2.05;      % K-Faktor
b  = 2;         % Br�ckenfaktor = Anzahl aktiv gedehnter DMS in der Br�cke
eps = 1000;     % Dehnung [um/m] 
Ue = 1.0;       % Br�ckenspeisespannung [V]
