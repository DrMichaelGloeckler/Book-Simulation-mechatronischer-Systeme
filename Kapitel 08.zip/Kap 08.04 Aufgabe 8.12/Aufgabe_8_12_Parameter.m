% Parameter f�r die Aufgabe 8.12
% Motorparameter Siemens 1GG6 164-0JG40-7NV5

Ra = 0.122;                 % Ankerwiderstand [Ohm]
La = 1.35e-3;               % Ankerinduktivit�t [H]
wN = 2900*pi/30;            % Nennwinkelgeschwindigkeit [rad/s]
PN = 111e3;                 % Nennleistung [W]
MN = 355;                   % Nenndrehmoment [Nm]
iN = 200;                   % Nennstrom [A]
Km = MN/iN;                 % Drehmomentkonstante Km [Nm/A]
Ke = Km;                    % Spannungskonstante [Vs/rad]
Jmot = 0.38;                % Rotortr�gheitsmoment [kg.m2]
