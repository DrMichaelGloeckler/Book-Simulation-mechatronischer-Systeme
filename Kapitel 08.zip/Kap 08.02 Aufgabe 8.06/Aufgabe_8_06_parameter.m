% Parameter f�r die Aufgabe 8.6 
clear *

p0 = 40e5;              % Systemdruck [Pa] (40e5 Pa = 40 Bar)
m  = 8.4;               % Masse [kg]

% Differenzialzylinder
cylinder.A_A = 0.003;   % Kolbenfl�che [m2] A-Seite
cylinder.A_B = 0.002;   % Ringfl�che [m2] B-Seite
cylinder.h   = 0.3;     % Zylinderhub [m]
cylinder.y0  = 0;       % Anfangsposition [m]
cylinder.Vt_A = 1e-4;   % Totvolumen A-Seite [m3]
cylinder.Vt_B = 1e-4;   % Totvolumen B-Seite [m3]
cylinder.ck   = 1e6;    % Kontaktsteifigkeit [N/m]
cylinder.dk   = 150;    % Kontaktd�mpfung [Ns/m]

% Ventil
valve.Amax    = 2.2e-4; % max. Ventil�ffnungsfl�che [m2]
valve.b       = 2.2e-2; % Steuerkantenbreite [m]
valve.y0      = 8e-4;   % negative �berdeckung [m]
valve.Cd      = 0.7;    % Durchflusskoeffizient / Discharge coefficient
valve.Re_crit = 12;     % Critical Reynolds Number
valve.A_leak  = 1e-12;  % Leakage area (m^2)

% D�se A
O_A  = 1e-4;            % Fl�che [m2]

% digitaler Druckregler
ctrl.Tab  = 1e-3;       % Abtastzeit [s]
ctrl.P    = -2e-9;      % P-Anteil [m/Pa] 
ctrl.Tn   = 0.01;       % Nachstellzeit [s]
ctrl.Umax = 5e-3;       % max. Stellgr��e [m/Pa]
                        