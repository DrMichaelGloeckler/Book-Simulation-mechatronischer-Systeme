% Parameter f�r die Aufgabe 8.14
clear *
clc

% Motorparameter, siehe Aufgabe 8.12
Aufgabe_8_12_Parameter;

%__________________________________________________________________________
% Parameter des Stromreglers (Werte nach dem Betragsoptimum)
Te   = La/Ra;       % elektrische Zeitkonstante [s]
Tt_i = 125e-6;      % Abtastzeit [s] des Stromreglers = Totzeit
Kp_i = Ra*Te/2/Tt_i;% Verst�rkung [V/A]
Ki_i = Kp_i/Te;     % Nachstellzeit [s]

%__________________________________________________________________________
% Parameter des Drehzahlreglers (nur Motor, ohne Antriebsstrang)
Ters_i = 2*Tt_i;
Kp_n = Jmot/2/Ters_i/Km;    % P-Anteil [Nm/(rad/s)] des Drehzahlreglers
Ki_n = Jmot/8/Ters_i^2/Km;  % I-Anteil [Nm*s/(rad/s)] des Drehzahlreglers
