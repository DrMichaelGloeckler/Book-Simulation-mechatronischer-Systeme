% Aufgabe_8_7_parameter.m
% Parameter f�r Aufgabe 8.7
% Das Modell Aufgabe_8_6.slx wird mit 3 unterschiedlichen Parameter-
% s�tzen simuliert. 

%__________________________________________________________________________
% 1.) Totzeit 0s
Kp = 110.0;   % Reglerverst�rkung
T1 = 0.1;   % PT1-Zeitkonstante [s]
Tab= 1e-3;  % Abtastzeit [s]

Tt = 0.000; % Rechentotzeit [s]

clc;
sim('Aufgabe_8_6');
    plot(simout.Time,simout.Data);
    grid on;
    xlabel('Zeit [s]');
    ylabel('Soll- und Istwert');
    title(['Totzeit ' num2str(Tt) ' s'])

disp('weiter mit Tastendruck. ')
pause;


%__________________________________________________________________________
% 2.) Totzeit 0.005s
Kp = 12.5;   % Reglerverst�rkung
Tt = 0.005; % Rechentotzeit [s]

clc;
sim('Aufgabe_8_6');
    plot(simout.Time,simout.Data);
    grid on;
    xlabel('Zeit [s]');
    ylabel('Soll- und Istwert');
    title(['Totzeit ' num2str(Tt) ' s'])

disp('weiter mit Tastendruck. ')
pause;

%__________________________________________________________________________
% 2.) Totzeit 0.005s
Kp = 7.2;   % Reglerverst�rkung
Tt = 0.01; % Rechentotzeit [s]

clc;
sim('Aufgabe_8_6');
    plot(simout.Time,simout.Data);
    grid on;
    xlabel('Zeit [s]');
    ylabel('Soll- und Istwert');
    title(['Totzeit ' num2str(Tt) ' s'])

disp('Ende. ')
