% Motordaten f�r den Vorschubantrieb
%__________________________________________________________________________

clear *;
clc;

%__________________________________________________________________________
% Parameter eines Bosch-Rexroth MSK071E-0200-NN Synchron-Servomotors
%__________________________________________________________________________
Ra = 1.16;          % Wicklungswiderstand [Ohm]
La = 9.15e-3;       % Wicklungsinduktivit�t [H]
Km = 2.51;          % Drehmomentkonstante [Nm/A]
Ke = 154.6/1000/(2*pi/60);   % Spannungskonstante [Vs/rad]
Jm = 0.00290;       % Rotortr�gheitsmoment [kgm2]
Ua = 400;           % Ankerspannung [V]

%__________________________________________________________________________
Te = La/Ra;         % elektr. Zeitkonstante [s]

%__________________________________________________________________________
% Parameter des Stromreglers (nach dem Betragsoptimum)
Tab_i = 100e-6;     % Abtastzeit [s] des Stromreglers
Tt   = Tab_i;       % Totzeit [s] des Stromreglers
Kp_i = Ra*Te/2/Tt;  % Verst�rkung [V/A]
Tn_i = Te;          % Nachstellzeit [s]

%__________________________________________________________________________
% Parameter der Mechanik
i_gear = 22;        % Getriebe�bersetzung [-]
J_2 = 1.0;          % Tr�gheitsmoment [kgm^2]     
c_2 = 1e4;          % f0 = 16 Hz
d_2 = 5e0;          % D = 0.025


%__________________________________________________________________________
% Parameter des Drehzahlreglers
Tab_n = 200e-6;         % Abtastzeit [s] des Drehzahlreglers
Ters_i = 2*Tt + Tab_n;  % gilt f�r den Fall einer zus�tzlichen Totzeit des 
                        % Drehzahlreglers
Kp_n = 1.4;             % P-Anteil [Nm/(rad/s)] des Drehzahlreglers
Tn_n = 2e-3;            % Nachstellzeit [s]

