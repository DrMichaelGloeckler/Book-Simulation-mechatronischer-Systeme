% Gesamtmodell_Zylinder_Parameter
clear;
clc;

% Zylindergeometrie
r_A = 0.125;                % Radius [m]
r_S = 0.100;                % Radius [m] der Kolbenstange
l   = 0.500;                % L�nge [m]
A_A = r_A*r_A*pi;           % Zylinderfl�che A [m^2]
A_B = A_A - r_S*r_S*pi;     % Zylinderfl�che B [m^2]
Vt_A = A_A * 0.05;          % Totvolumen A [m^3]
Vt_B = A_B * 0.05;          % Totvolumen A [m^3]

% Elastizit�tsmodul von �l
E_Oel = 1e9;                % [N/m^2]

% Dr�cke
pS = 300e5;                 % Systemdruck [Pa]
p_B_0 = pS/2;               % Anfangswert Druck B (Sch�tzwert)
p_A_0 = p_B_0*A_B/A_A;      % Anfangswert Druck A (Sch�tzwert)

% Dynamik
m = 5000;                   % Masse [kg]
d = 1e5;                    % D�mpfungskonstante [Ns/m]

% Anfangswerte
x0 = l/2;                   % Anfangsposition [m]
xp0 = 0;                    % Anfangsgeschwindigkeit [m/s]

disp(['Anfangsposition x0 = ' num2str(x0) ' m']);
