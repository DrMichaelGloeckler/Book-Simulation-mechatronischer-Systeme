% Aufgabe_8_6_parameter.m
% Parameter f�r Aufgabe 8.6

Kp = 5.0;   % Reglerverst�rkung
T1 = 0.1;   % PT1-Zeitkonstante [s]
Tab= 1e-3;  % Abtastzeit [s]

Tt = 0.005; % Rechentotzeit [s]
