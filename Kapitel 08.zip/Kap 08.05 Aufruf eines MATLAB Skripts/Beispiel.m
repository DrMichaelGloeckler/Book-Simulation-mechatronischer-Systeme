% Beispiel.m
clc

if exist('Aufrufe','var') == 0
    Aufrufe = 0;
end
disp('Aufruf des Scripts Beispiel.m')
Aufrufe = Aufrufe + 1;
disp(['Dies ist der ' num2str(Aufrufe) '. Aufruf']);
