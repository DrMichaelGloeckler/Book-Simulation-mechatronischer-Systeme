% Parameter f�r die Aufgabe 8.13
clear *
clc

% Motorparameter, siehe Aufgabe 8.12
Aufgabe_8_12_Parameter;

%__________________________________________________________________________
% Parameter des Stromreglers (Werte nach dem Betragsoptimum)
Te   = La/Ra;       % elektrische Zeitkonstante [s]
Tt_i = 125e-6;      % Abtastzeit [s] des Stromreglers = Totzeit
Kp_i = Ra*Te/2/Tt_i;% P-Anteil [V/A] des Stromreglers
Ki_i = Kp_i/Te;     % I-Anteil [Vs/A] des Stromreglers
