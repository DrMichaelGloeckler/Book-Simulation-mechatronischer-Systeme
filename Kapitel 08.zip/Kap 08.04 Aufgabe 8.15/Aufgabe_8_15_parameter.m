% Parameter f�r die Aufgabe 8.15
clear *
clc

% Motorparameter
Aufgabe_8_12_Parameter;

%__________________________________________________________________________
% Parameter des Stromreglers (Werte nach dem Betragsoptimum)
Te   = La/Ra;       % elektrische Zeitkonstante [s]
Tt_i = 125e-6;      % Abtastzeit [s] des Stromreglers = Totzeit
Kp_i = Ra*Te/2/Tt_i;% Verst�rkung [V/A]
Ki_i = Kp_i/Te;     % Nachstellzeit [s]

%__________________________________________________________________________
% Parameter von Getriebe und Mechanik
iGear = 5;          % Gear ratio
rGear = 0.22;       % Wheel Radius [m]
iGes  = iGear/rGear;
cMech = 1e7;        % Spring rate [N/m]
mMech = 200;        % Mass [kg]
dMech = 1e4;        % Viscous friction coefficient [Ns/m]

fMech = sqrt(cMech/mMech)/2/pi;     % Eigenfrequenz [Hz]
JredMech = mMech/(iGear/rGear)^2;   % reduziertes Tr�gheitsmoment [kgm2]

%__________________________________________________________________________
% Parameter des Drehzahlreglers (Motor mit Antriebsstrang)
Ters_i = 2*Tt_i;
Kp_n = Jmot/2/Ters_i/Km;    % P-Anteil [Nm/(rad/s)] des Drehzahlreglers
Ki_n = 2*(Jmot+JredMech)*(Jmot/2/Ters_i)^2/Km;  % I-Anteil [Nm*s/(rad/s)] des Drehzahlreglers
