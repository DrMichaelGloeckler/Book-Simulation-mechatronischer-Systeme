%==========================================================================
% Musterlösung der Aufgabe 10.1
% Die zeitdiskrete Übertragungsfunktion eines PT1-Gliedes wird durch ein
% lineares Neuron mit d0=0 nachgebildet.
%
% Datei: NeuronPT1_ohne_d0.m
%==========================================================================
clear variables
clc

%--------------------------------------------------------------------------
% Bezeichnung der verwendeten Größen 
% u = Eingangsgröße u(k) für den Zeitschritt k
% U = Vektor der Eingangsgrößen u(k), k=1..4001
% y = Vektor der Ausgangsgrößen des PT1-Gliedes
% nbTDL = Länge der Speicherkette für alte Werte. Hier: nbTDL = 1, d.h.
%         hier werden u(k-1) und y(k-1) zu p(k) zusammen gesetzt.
% P = Matrix der Eingangsgrößen p(k) des Neurons, k=1..nSamples-1
% T = Vektor der Targets t(k), k=2..4001
%   Anm.: Länge(P) = Länge(T) = Länge(X)-nbTDL (hier:=nSamples-1)
% p = Vektor der Eingangsgrößen p(k) = [u(k-1);y(k-1)] 
% a = Ausgangsgröße a(k) des Neurons für den Zeitschritt k 
% A = Vektor der Ausgangsgrößen des Neurons für alle Zeitschritte 
%--------------------------------------------------------------------------

% Parameter
nbSamples = 4001;
Tab = 1e-2;                     % Abtastzeit 0.01s

%% Input Daten erzeugen
% Zufallszahlen im Wertebereich -1..1 entsprechen einem Rauschsignal
rng(1);
U = 2*rand([1,nbSamples])-1;       % U = inputs

%% Simulation des PT1-Gliedes
% Strecke: PT1
%            2.7 
% G(s) = -----------
%         0.5 s + 1
%
Gs = tf(2.7,[0.5, 1]);          % Systemobjekt, zeitkontinuierlich
Gz = c2d(Gs,Tab,'zoh');         % Systemobjekt, zeitdiskret
disp('zeitdiskrete Übertragungsfunktion G(z)')
Gz
disp(' ')

% Simulation mit Gz ergibt die Targets für das Neuronale Netz
y = lsim(Gz,U,(0:nbSamples-1)*Tab)';    % im Zeitintervall 0..


%% Inputs und Targets zusammenbauen für das Training des Neurons 
% TDL=1:nbTDL
nbTDL = 1;                              % Anzahl der Verzögerungsschritte
% nbSamples = length(U);
P  = zeros(2*nbTDL,nbSamples-nbTDL);    % Speicherplatz reservieren
T  = zeros(1,nbSamples-nbTDL);          % Speicherplatz reservieren
% wegen d0=0 entfällt u(k) in P
for k=1+nbTDL:length(U) 
    P(:,k) = [U(k-1:-1:k-nbTDL)';...    % 1 Eingangsgröße u(k-1)
              y(k-1:-1:k-nbTDL)';];     % 1 Rückführgröße y(k-1)
    T(:,k) = y(k);                      % 1 Zielgröße y(k)
end

%% Neuronales Netz anlegen 
numHiddenLayer = 0;        % es gibt nur einen Layer, daher keine Hidden Layer 
% custom neural network 
net = network(1,...                 % numInputs
              1+numHiddenLayer,...  % numLayers
              1,...                 % biasConnect (könnte in dem Bsp. =0 gesetzt werden)
              1,...                 % inputConnect
              0,...                 % layerConnect
              1);                   % outputConnect

%% Training des Neuronalen Netzes 
% Choose a Training Function
% For a list of all training functions type: help nntrain
% 'trainlm' is usually fastest.
% 'trainbr' takes longer but may be better for challenging problems.
% 'trainscg' uses less memory. Suitable in low memory situations.
net.trainFcn = 'trainlm';
net.divideFcn = 'dividerand';

% Setup Division of Data for Training, Validation, Testing
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 15/100;
net.divideParam.testRatio = 15/100;

% Train the Network
[net,tr] = train(net,P,T);
% View the Network
view(net)
disp(['Network Weights W = ',num2str(net.IW{1})])
disp(['Network Bias    b = ',num2str(net.b{1})])
disp(' ')

% Test the Network
A = net(P);             % Interferenz: P = inputs, A = ouputs 
e = gsubtract(T,A);     % Fehler e = targets T - outputs A
performance = perform(net,T,A);
disp(['Performance mit der Funktion ''',net.performFcn,''' = ', num2str(performance)])


%% Vergleich plotten
figure, clf
plot(y), hold on, plot(A,'r.')
grid on
xlabel('sample'), ylabel('position y')
legend('PT1-Glied','Neuron','location','best' )
title('PT1-Glied, Variante 1 mit Custom Network')

%% Simulink-Block für das Neuronale Netz erstellen 
% gensim(net,Tab);

