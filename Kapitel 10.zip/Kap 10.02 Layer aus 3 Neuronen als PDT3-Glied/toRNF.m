function sysRNF = toRNF(sys)
%toRNF Umwandlung in die Regelungsnormalform 
%      nach Lunze, Regelungstechnik 1, Kap.4.4, Seite 88f, Gln.(4.62) bis (4.65) 
%

% 22.09.2023 OK

sysTF = tf(sys);                    % transfer function

m = length(sysTF.Numerator{1});
n = length(sysTF.Denominator{1});
if m>n
    error('m>n')
else
    ord = max([m,n]);
end

% Standardform aN:=1
sysTF.Numerator{1} = sysTF.Numerator{1}/sysTF.Denominator{1}(1);
sysTF.Denominator{1} = sysTF.Denominator{1}/sysTF.Denominator{1}(1);

% System matrices
Ac = [ zeros(ord-2,1), eye(ord-2,ord-2); ...
       -sysTF.Denominator{1}(end:-1:2) ];
Bc = [zeros(ord-2,1); 1];
Cc = ((sysTF.Numerator{1}(end:-1:2))' - sysTF.Numerator{1}(1)*(sysTF.Denominator{1}(end:-1:2))')';
Dc = sysTF.Numerator{1}(1);

sysRNF = ss(Ac,Bc,Cc,Dc);

end