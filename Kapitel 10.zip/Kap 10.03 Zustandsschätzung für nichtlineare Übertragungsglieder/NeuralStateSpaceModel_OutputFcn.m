function y = NeuralStateSpaceModel_OutputFcn(x,u)
%% auto-generated output function of neural state space system
%# codegen
y = x;
