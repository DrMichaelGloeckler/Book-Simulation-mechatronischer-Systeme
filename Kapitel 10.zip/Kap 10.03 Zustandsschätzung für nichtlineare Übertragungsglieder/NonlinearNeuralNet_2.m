%==========================================================================
% Script Teil 2 für Test des trainierten Neuronalen Netzes zur Nachbildung 
% mit anderen Eingangsgrößen.
% 
% Dateil: NonlinearNeuralNet_2.m
%==========================================================================
clear variables
clc

%% Daten des Beispiels 'Magnetic Levitation'
NonlinearNeuralNetData;

% Datensatz der Eingangsgröße laden (Teil der Deep Learning Toolbox)
load('TestInputs.mat');
nbSamples = length(maglevInputs);
Tend = (nbSamples-1)*Tab;        % Ende-Zeit der Simulation [s]

% Daten vom Training laden, insbesondere: Skalierungsdaten, Eingangsgröße
% xPS, yPS, ypPS, yppPS, nbTDL, 'inputsScaled', 'targetsScaled'
load('TrainData.mat');

% Anfangswerte f.d. TDL-Bausteine 
[u0Scaled,~] = mapminmax('apply',cell2mat(maglevInputs(1)),xPS);        % Stellgröße u
y0Scaled = targetsScaled(1,1); 
y1Scaled = targetsScaled(2,1); 

%% Inferenz in Simulink: Simscape-Modell und verschw. Varianten für die 
% Beschaltung des Neuronalen Netzes.  
outNN = sim('MaglevNeuralNet.slx');

%% Ergebnisse plotten
figure(4), clf
set(4,'Position',[300,250,700,500])
% Positionen
subplot(3,1,1)
title('Model,Neural Net a(k), Neural Net a(k+1)')
plot(outNN.simout.Data(:,2),'b'),   % Position aus dem 'Magnetic Levitation' Modell
hold on, 
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,4),'r.'),   % Position aus dem Neural Net, closed loop
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,11),'k.'),   % Position aus dem Neural Net
grid on
xlabel('Sample')
ylabel('Position y0,a0')
legend('Model','Neural Net a(k)','Neural Net a(k+1)','location','best')
% Geschwindigkeiten
subplot(3,1,2)
plot(outNN.simout.Data(:,5),'b'),   % Geschwindigkeit aus dem 'Magnetic Levitation' Modell
hold on, 
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,7),'r.'),   % Geschwindigkeit aus dem Neural Net, closed loop
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,12),'k.'),   % Geschwindigkeit aus dem Neural Net
grid on
xlabel('Sample')
ylabel('Velocity y1,a1')
legend('Model','Neural Net a(k)','Neural Net a(k+1)','location','best')
% Beschleunigungen
subplot(3,1,3)
plot(gradient(outNN.simout.Data(:,5),Tab),'b'),   % Beschleunigung aus dem 'Magnetic Levitation' Modell
hold on, 
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,10),'r.'),   % Beschleunigung aus dem Neural Net
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,13),'k.'),   % Beschleunigung aus dem Neural Net
grid on
xlabel('Sample')
ylabel('Acceleration y2,a2')
legend('Model','Neural Net a2(k-1)','Neural Net a2(k)','location','best')

%
figure(5), clf
set(5,'Position',[300,250,700,500])
subplot(3,1,1)
% Positionen
title('Model,Neural Net a(k), Neural Net a(k+1)')
plot(outNN.simout.Data(:,2),'b'),   % Position aus dem 'Magnetic Levitation' Modell
hold on, 
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,4),'r.'),   % Position aus dem Neural Net, closed loop
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,11),'k.'),   % Position aus dem Neural Net
grid on
xlabel('Sample')
ylabel('Position y0,a0')
legend('Model','Neural Net a(k)','Neural Net a(k+1)','location','best')
xlim([390,440])
% Geschwindigkeiten
subplot(3,1,2)
plot(outNN.simout.Data(:,5),'b'),   % Geschwindigkeit aus dem 'Magnetic Levitation' Modell
hold on, 
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,7),'r.'),   % Geschwindigkeit aus dem Neural Net, closed loop
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,12),'k.'),   % Geschwindigkeit aus dem Neural Net
grid on
xlabel('Sample')
ylabel('Velocity y1,a1')
legend('Model','Neural Net a(k)','Neural Net a(k+1)','location','best')
xlim([390,440])
% Beschleunigungen
subplot(3,1,3)
plot(gradient(outNN.simout.Data(:,5),Tab),'b'),   % Beschleunigung aus dem 'Magnetic Levitation' Modell
hold on, 
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,10),'r.'),   % Beschleunigung aus dem Neural Net
plot((1+nbTDL:nbSamples),outNN.simout.Data(1+nbTDL:nbSamples,13),'k.'),   % Beschleunigung aus dem Neural Net
grid on
xlabel('Sample')
ylabel('Acceleration y2,a2')
legend('Model','Neural Net a2(k-1)','Neural Net a2(k)','location','best')
xlim([390,440])
