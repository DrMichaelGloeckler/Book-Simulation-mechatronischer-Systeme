% NonlinearNeuralNetData.m

% Daten des Beispiels 'Magnetic Levitation'
g = 9.80;       % Erdbeschleunigung (m/s/s)
beta = 12;      % Dämpfungskonstante
alpha = 15;     % Konstante f. d. Magnetkraft
M  = 3;         % Masse 
y0  = 0.5;      % Anfangsposition [m] f. d. Simulation
Tab = 0.01;     % Abtastzeit (s) 
% Hard Stop Parameter, empirisch ermittelt
HSc = 3e7;      % 
HSd = 5e-1;     % 
HSs = 1e-3;     % 
