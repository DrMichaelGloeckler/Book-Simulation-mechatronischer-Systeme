%==========================================================================
% Script Teil 1 für Entwurf, Training und Test eines Neuronalen Netzes zur
% Nachbildung eines nichtlinearen des Übertragungsgliedes.
% 
% Dateil: NonlinearNeuralNet_1.m
%==========================================================================
clear variables
clc
        
%% Daten des Beispiels 'Magnetic Levitation'
NonlinearNeuralNetData;

% Datensatz der Eingangsgröße laden 
load('TrainInputs.mat');
Tend = (length(maglevInputs)-1)*Tab;        % Ende-Zeit der Simulation [s]

%% Simulation 'Magnetic Levitation' um die Targets für t0, t1 und t2 für 
%  Lage y, Geschwindkeit dy/dt und Beschleunigung d2y/dt2 zu erhalten.
disp('Simulation ''Magnetic Levitation'' in Simulink ')
out = sim('MaglevSimscape.slx');

%% Eingangs- und Ausgangsgrößen für das Neuronale Netz skalieren auf den Wertebereich [-1..1] 
% unskalierte inputs, outputs
inputs   = out.simout.Data(:,1)';               % Eingangsgröße u 
targets(1,:) = out.simout.Data(:,2);            % Zielgröße t0 = y = Position aus der Simulation (Simulink)
targets(2,:) = out.simout.Data(:,3);            % Zielgröße t1 = yp = Geschwindigkeit aus der Simulation (Simulink)
targets(3,:) = gradient(out.simout.Data(:,3),Tab); % Zielgröße t2 = ypp = Beschleunigung, nachträglich berechnet aus yp 

% Skalieren auf [-1..1]
% Die Skalierung ist hier besonders wichtig, weil die 3 Target-Größen 
% sehr unterschiedlich große Zahlenwerte haben und daher ohne die Skalierung 
% sehr unterschiedlich stark in die Performance-Kennzahl eingehen und damit in das Training.  
[inputsScaled,xPS]         = mapminmax(inputs,-1,1);        % Stellgröße u
[targetsScaled(1,:),yPS]   = mapminmax(targets(1,:),-1,1);  % Ausgangsgröße y0
[targetsScaled(2,:),ypPS]  = mapminmax(targets(2,:),-1,1);  % erste Ableitung. y1
[targetsScaled(3,:),yppPS] = mapminmax(targets(3,:),-1,1);  % zweite Ableitung. y2

%% Inputs P und Targets T zusammenbauen für TDL=1:nbTDL
nbTDL = 1;          % Anzahl Speicherstellen in den TDL-Bausteinen 
nbU = 1;            % Anzahl Stellgrößen u, 1. Eingang
nbY = 2;            % Anzahl Target- bzw. Rückführgrößen, 2. Eingang 
nbA = 3;            % Anzahl Ausgangsgrößen a
nbSamples = length(inputs);
P  = zeros((nbU+nbY)*nbTDL,nbSamples-nbTDL);    % Speicherplatz reservieren
T  = zeros(nbA,nbSamples-nbTDL);                % Speicherplatz reservieren
% Anfangswerte setzen für k = 1:nbTDL
T(:,1:nbTDL) = [targetsScaled(1,1:nbTDL);...    % 1. Zielgröße t0 = Position
                targetsScaled(2,1:nbTDL);...    % 2. Zielgröße t1 = Geschwindigkeit
                targetsScaled(3,1:nbTDL);...    % 3. Zielgröße t2 = Beschleunigung 
                        ];  
for k=1+nbTDL:length(inputs) 
    P(:,k) = [inputsScaled(k-1:-1:k-nbTDL)';...     % 1 Eingangsgröße 
              targetsScaled(1,k-1:-1:k-nbTDL)';...  % 1. Zielgröße t0 = Position
              targetsScaled(2,k-1:-1:k-nbTDL)';...  % 2. Zielgröße t1 = Geschwindigkeit
                     ];
    T(:,k) = [targetsScaled(1,k);...                % 1. Zielgröße t0 = Position
              targetsScaled(2,k);...                % 2. Zielgröße t1 = Geschwindigkeit 
              targetsScaled(3,k-1);...              % 3. Zielgröße t2 = Beschleunigung, 1 Zeitschritt verzögert
                     ];
end

%% Kern des Neuronalen Netzes aufbauen: 1 Hidden Layer + 1 Output Layer 
% Training Function
trainFcn = 'trainbr';  % Bayesian regularisation backpropagation

hiddenLayerSize = 40;   % Anzahl Neuronen im Hidden Layer 
net = feedforwardnet(hiddenLayerSize,trainFcn);

% Setup Division of Data for Training, Validation, Testing
net.divideParam.trainRatio = 85/100;
net.divideParam.valRatio = 0/100;           % Validierung ist bei Bayesian regularisation nicht erforderlich
net.divideParam.testRatio = 15/100;

% Train the Network
disp('Training des Neuronalen Netzes')
[net,tr] = train(net,P(:,1+nbTDL:end),T(:,1+nbTDL:end));

% Test the Network
a(:,1+nbTDL:nbSamples) = net(P(:,1+nbTDL:end));
e = gsubtract(T,a);
performance = perform(net,T,a)

% View the Network
% view(net)

%% Inferenz, d.h. Aufruf des Netzes mit allen Eingangsgrößen P
a(:,1+nbTDL:nbSamples) = net(P(:,1+nbTDL:end));

% Rück-Skalieren
yUnscaled   = mapminmax('reverse',a(1,:),yPS);
ypUnscaled  = mapminmax('reverse',a(2,:),ypPS);
yppUnscaled = mapminmax('reverse',a(3,:),yppPS);

% Plotten
figure(2), clf
set(2,'Position',[300,250,700,500])
subplot(3,1,1)
plot(targets(1,:)), hold on, plot((1+nbTDL:nbSamples),yUnscaled(1+nbTDL:nbSamples),'k.')
grid on
xlim([0,50])
ylabel('position y0')
legend('Targets t','Net Outputs a','location','best' )
subplot(3,1,2), plot(targets(2,:)), hold on, plot((1+nbTDL:nbSamples),ypUnscaled(1+nbTDL:nbSamples),'k.')
ylabel('velocity y1')
legend('Targets t','Net Outputs a','location','best' )
grid on
xlim([0,50])
% subplot(3,1,3), plot(targets(3,:)), hold on, plot((1+nbTDL:nbSamples),yppUnscaled(1+nbTDL:nbSamples),'r.')
subplot(3,1,3), plot((2:nbSamples),targets(3,1:end-1)), hold on, plot((1+nbTDL:nbSamples),yppUnscaled(1+nbTDL:nbSamples),'k.')
xlabel('Sample'), ylabel('acc. y2')
legend('Targets t(k-1)','Net Outputs a(k)','location','best' )
grid on
xlim([0,50])


%% Simulink-Modell des Neuronalen Netzes erstellen
% gensim(net,'sampletime',Tab,'inputmode','port','outputmode','port');
gensim(net,'sampletime',Tab,'inputmode','none','outputmode','none');
disp('Feedforward Net erstellt. Bitte speichern unter... ')

% save('TrainData.mat','inputsScaled','xPS','nbTDL','targetsScaled','yPS','ypPS','yppPS');
