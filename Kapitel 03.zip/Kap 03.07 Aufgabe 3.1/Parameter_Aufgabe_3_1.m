% Parameter f�r die Aufgabe 3.1 
m = 0.2;    % Masse [kg]
c = 10;     % Federsteifigkeit [N/m]
d = 0.5;    % D�mpfungskonstante [Ns/m]
g = 9.81;   % Erdbeschleunigung
