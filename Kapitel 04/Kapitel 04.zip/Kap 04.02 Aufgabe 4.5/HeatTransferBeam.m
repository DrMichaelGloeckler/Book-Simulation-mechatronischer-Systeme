%HeatTransferBeam.m
%
%  dT       d�T
%  -- = a * ---
%  dt       dz�
%
% Beispiel: Temperaturverteilung in einem Stab.
% Stab hat anfangs �berall eine Temperatur von 20deg.
% Zum Zeitpunkt t=0 wird die Temperatur bei z=0 auf 40deg
% erh�ht und konstant gehalten. 
% Temperatur T
% Zeit t
% Wegkoordinate z
%
% Berechnung mittels R�ckw�rtsdifferential
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

%--------------------------------------------------------------------------
% Vorgabewerte
%--------------------------------------------------------------------------
l = 0.1;            % Stabl�nge 0.1m
a = 1e-4;           % Konstante [m2/s]

% St�tzpunkte in t-Richtung (Zeit)
Tsim = 10;                  % Simulationszeitdauer [s]
npts = 100;                 % Anzahl Zeit-St�tzpunkte
t  = linspace(0,Tsim,npts); % Simulationszeitraster
dt = t(2)-t(1);             % Zeitschrittweite [s]

% a*dt/dz^2 <= 0.5          % Wegschrittweite mit Faustformel bestimmen
dz = sqrt(2*a*dt);

% St�tzpunkte in z-Richtung = Positionsraster [m]
z  = (0:dz:l);

% Temperatur-Matrix vorbelegen; 
%   Zeile = Zeitraster, Spalte = Positionsraster
T = zeros(length(t),length(z));
% Anfangswerte
T0 = 20;                    % 20 �C Anfangstemperatur im ganzen Stab
TE = 40;                    % 40 �C Anfangstemperatur ganz aussen
T(1,:) = T0 * ones(size(z));% in der ersten Zeile steht nun �berall T0
T(1,1) = TE;                % Anfangstemperatur TE ganz aussen setzen

figure; hold off; grid on;
%--------------------------------------------------------------------------
% Berechnungsschleifen
%--------------------------------------------------------------------------
for it=2:length(t)
    % Schleife �ber alle Zeitst�tzpunkte, beginnen bei 2
    % (Zeitst�tzpunkt 1 wurde oben schon initialisiert)
    
    % Randwerte (d.h. r�umliche Randbedingungen) vorgeben. 
    T(it,1) = TE;           % Randbedingung bei z=0: TE
    T(it,length(z)) = T0;   % Randbedingung bei z=l: T0
    
    for iz=2:length(z)-1
        % Schleife �ber alle Positionsst�tzpunkte, beginnen bei 2
        
        % Differenzenverfahren. 
        % im eindimensionalen Fall werden nur die Gln.(4.116), (4.118) gebraucht
        T(it,iz) = T(it-1,iz) + a*dt/dz^2 * ...
            ( T(it-1,iz+1) - 2*T(it-1,iz) + T(it-1,iz-1));
    end
    plot(z,T(it,:));
    drawnow;
end
xlabel('Position z [m]'); ylabel('Temperatur [�C]');
grid on;

figure;
surf(z,t,T); 
xlabel('Zeit t []'); 
ylabel('Position z [m]'); 
zlabel('Temperatur T [�C]');
