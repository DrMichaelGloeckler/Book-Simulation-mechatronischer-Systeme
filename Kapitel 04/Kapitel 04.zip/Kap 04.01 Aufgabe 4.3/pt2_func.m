function [dx,y] = pt2_func(x,u)
%pt2_func   berechnet die Ableitung dx/dt eines PT2-Gliedes mit der 
%           �bertragungsfunktion G(s) = y/u = 1/((T2*s)^2+T1*s+1)
%   
%   [dx,y] = pt2_func(x,u);
%
%       x   = state value
%       u   = input value
%       y   = output value
%       dx  = dx/dt
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

% Systemparameter der Strecke festlegen
T1 = 0.050;     % Zeitkonstante 50ms
T2 = 0.1;       % Zeitkonstante 100ms

% Systemmatrix
A  = [(-T1/T2/T2)  (-1/T2/T2) 
               1           0 ];
         
% Steuervektor  
B  = [ 1 0 ]';

% Beobachtervektor  
C  = [0 (1/T2/T2)];  

% Durchgangskoeffizient
D  = 0;  

% x in Spaltenvektor umwandeln, falls n�tig
[nrows,ncolumns] = size(x);
if ncolumns==1
    % x ist bereits ein Spaltenvektor
elseif nrows==1
    % x ist bereits ein Zeilenvektor
    x = x';
else
    % x ist weder Zeilen- noch Spaltenvektor
    error('x ist kein Vektor');
end

% Berechnung auf Basis der Zustandsdarstellung
dx = A*x + B*u;
y  = C*x + D*u;

return;
