function [x,y] = myEuler(f,t,u,x0)
%myEuler  Funktion zur Euler-Integration einer Differentialgleichung. 
%         dy/dt = f(t,y(t)) 
%         Die zu integrierende Funktion f muss in der Form 
%         [dx,y] = f(x,u) vorliegen
%
%   f   = Verweis (function handle) auf die Differentialgleichung [dx/dt,y] = f(x,u)
%   t   = [t0 t0+dt ... tfinal] [s]
%   u   = Eingangssignal u(t), muss f�r jeden Zeitschritt gegeben sein
%   x0  = x(t0)
%   x   = Zustandsvektor
%   y   = Ausgangssignal
%   dx  = Ableitung des Zustandsvektors nach der Zeit = dx/dt
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

%--------------------------------------------------------------------------
% Hinweise:
%   x  = Zustandsvektor
%   xp = erste Ableitung des Zustandsvektors
%   y  = Ausgangsgr��e
%
% Die Programmzeilen 35 bis 47 sind f�r die Berechnung nicht notwendig.
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Eingabeparameter pr�fen
%--------------------------------------------------------------------------
if nargin<4
    error('not enough input arguments');
elseif nargin>4
    error('too many input arguments');
end
if length(u)~= length(t)
    error('t und u m�ssen gleiche L�nge haben');
end

% Felder initialisieren (nur zur Rechenzeitoptimierung)
x  = zeros(length(x0),length(t));   % Zustandsvektor x 
xp = zeros(length(x0),length(t));   % erste Ableitung des Zustandsvektors x 
y  = zeros(1,length(t));            % Ausgangsgr��e y 


%==========================================================================
% hier beginnt die eigentliche Berechnung
%==========================================================================
%--------------------------------------------------------------------------
% Anfangswerte zum Zeitpunkt t0
%--------------------------------------------------------------------------
x(:,1) = x0;                    	 % Anfangswert des Zustands

%--------------------------------------------------------------------------
% F�r alle Zeitschritte werden die Werte rekursiv berechnet
%--------------------------------------------------------------------------
for k=1:length(t)-1
    % aktueller Zeitpunkt t(k), aktueller Eingangswert x(k), 
    % aktuelle Ableitung xp(k) = dx/dt 
    [xp(:,k),y(k)] = f( x(:,k), u(k) );
    
    % aktueller Zeitschritt dt; es k�nnen auch variable Schrittweiten
    % verwendet werden.
    dt = t(k+1) - t(k);
    
    % naechster Zeitschritt aus Euler-Integration mit
    x(:,k+1) = x(:,k) + dt*xp(:,k);  
    
end
%--------------------------------------------------------------------------
% Ausgangswert y am letzten Zeitschritt berechnen
%--------------------------------------------------------------------------
k=length(t);
    % aktueller Zeitpunkt t(k), aktueller Eingangswert x(k),
    % aktuelle Ableitung dx/dt
    [xp(:,k),y(k)] = f( x(:,k), u(k) );

return;
