function [dx,y] = pt1_func(x,u)
%pt1_func   berechnet die erste Ableitung dx/dt der Zustandsgr��e x eines 
%           PT1-Gliedes mit der �bertragungsfunktion G(s) = Y/U = 1/(T1*s+1)
%           und das Ausgangssignal y.
%   
%   [dx,y] = pt1_func(x,u);
%
%       x   = state value
%       u   = input value
%       y   = output value
%       dx  = derivative dx/dt
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

% x in einen Spaltenvektor umwandeln, falls n�tig
[nrows,ncolumns] = size(x);
if ncolumns==1
    % x ist bereits ein Spaltenvektor
elseif nrows==1
    % x ist bereits ein Zeilenvektor => Transponieren
    x = x';
else
    % x ist weder Zeilen- noch Spaltenvektor
    error('x ist kein Vektor');
end



%--------------------------------------------------------------------------
% Systemparameter der Strecke festlegen
%--------------------------------------------------------------------------
T1 = 0.020;     % Zeitkonstante 20ms

%--------------------------------------------------------------------------
% Z�hler- und Nennerpolynom der �bertragungsfunktion
%--------------------------------------------------------------------------
num = 1;
den = [T1 1];

%--------------------------------------------------------------------------
% Umwandlung in Zustandsraumdarstellung
%--------------------------------------------------------------------------
[A,B,C,D]  = tf2ss( num, den );


%==========================================================================
% Berechnung auf Basis der Zustandsdarstellung
%==========================================================================
dx = A*x + B*u;     % erste Ableitung dx/dt der Zustandsgr��e x
y  = C*x + D*u;     % Ausgangssignal y


return;
