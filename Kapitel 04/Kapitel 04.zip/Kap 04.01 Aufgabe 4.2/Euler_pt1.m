% Euler-Integration der Sprungantwort eines PT1-Gliedes
% siehe: Aufgabe 4.2
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

%==========================================================================
% Euler-Integration
%==========================================================================
%--------------------------------------------------------------------------
%   Zeitvektor
%--------------------------------------------------------------------------
t0 = 0;                     % Anfangszeit
dt = 0.01;                  % Schrittweite 0.01s
tfinal = ceil(0.2/dt)*dt;   % Simulationszeitdauer 0.2s
t = (t0:dt:tfinal);    

% Systemparameter festlegen
T1 = 0.020;     % Zeitkonstante 20ms

%--------------------------------------------------------------------------
%   Eingangssignal-Vektor: Einheitssprung
%--------------------------------------------------------------------------
u = ones(1,length(t));

%--------------------------------------------------------------------------
%   Startwert(e) f�r y
%--------------------------------------------------------------------------
y0 = 0;

%--------------------------------------------------------------------------
%   daraus die Startwert(e) f�r x berechnen
%--------------------------------------------------------------------------
x0 = [T1] .* y0;

%--------------------------------------------------------------------------
% Euler-Integrationsverfahren aufrufen
%--------------------------------------------------------------------------
[x,y] = myEuler(@pt1_func,t,u,x0);

%--------------------------------------------------------------------------
% Ergebnis plotten
%--------------------------------------------------------------------------
figure; 
plot(t,y,'m'); grid on; hold on;
if length(t)<50   % Marker setzen, falls weniger als 50 St�tzstellen
    plot(t,y,'m^')
end


%==========================================================================
% 1.Probe: Vergleich mit numerisch berechneter Sprungantwort
%==========================================================================
%--------------------------------------------------------------------------
% �bertragungsfunktion G(s) = num(s)/den(s) = 1 / (T1*s + 1)
%--------------------------------------------------------------------------
T1 = 0.020;     % Zeitkonstante 20ms
num = 1;
den = [T1 1];

% Sprungantwort mit MATLAB Funktion (aus: Control-Toolbox)
step(num,den);


%==========================================================================
% 2.Probe: Vergleich mit analytischer L�sung der Differentialgleichung 
%==========================================================================
%--------------------------------------------------------------------------
% analytische L�sung (siehe: separate Dokumentation)
%--------------------------------------------------------------------------
t = linspace(0,0.2);    % Zeitvektor anlegen
y = 1-exp(-t/T1);       % Ausgangssignal y(t) berechnen
plot(t,y,'rs');
title('magenta=Euler, blau=step(), rot=analytische L�sung');
grid on;
