% Euler-Integration der Sprungantwort eines PT1-Gliedes
% siehe: Aufgabe 4.1
%
% In diesem Beispiel werden alle Funktionen und Befehle direkt aus einer 
% Datei heraus aufgerufen.
% Variante b) Berechnung des Sch�tzwertes des Ausgangssignals y aus dem 
%             Sch�tzwert f�r den Zustandsvekor nach der Gleichung (4.94)
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

%--------------------------------------------------------------------------
% Systemparameter festlegen
%--------------------------------------------------------------------------
T1 = 0.020;     % PT1-Zeitkonstante = 20ms

%==========================================================================
% Euler-Integration
%==========================================================================
dt = 0.01;          % Schrittweite dt
t_end = 0.2;        % Simulationszeitdauer
t = (0:dt:t_end);   % Zeit-Vektor

%--------------------------------------------------------------------------
% �bertragungsfunktion: PT1
%--------------------------------------------------------------------------
num = 1;
den = [T1 1];
% Zustandsraumdarstellung
[A,B,C,D] = tf2ss(num,den);

%--------------------------------------------------------------------------
% Felder initialisieren (nur zwecks Laufzeitoptimierung)
%--------------------------------------------------------------------------
u = zeros(1,length(t));
y = zeros(1,length(t));
x = zeros(1,length(t));
xp= zeros(1,length(t));
dx= zeros(1,length(t));
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Anfangswerte zum Zeitpunkt t=0 setzen
%--------------------------------------------------------------------------
t(1) = 0;           % erster Zeitschritt bei t=0s
x(1) = 0 ;          % Anfangswert des Zustandsvektors = 0
u(1) = 1;           % Eingang = Sprungfunktion = 1 

%--------------------------------------------------------------------------
% F�r alle weiteren Zeitschritte werden die Werte rekursiv berechnet
%--------------------------------------------------------------------------
for k=1:length(t)-1
    % aktueller Zeitpunkt t(k)

    % n�chster Eingangswert (hier: Einheitssprung=1)
    u(k+1) = 1;
    
    % Berechnung der ersten Ableitung um Zeitpunkt t(k) nach Gl.(3.3.3)
    xp(:,k) = A*x(:,k) + B*u(k);
    
    % n�chster Wert des Zustandsvektors nach dem Euler-Verfahren nach Gl.(3.4.1.13)
    x(:,k+1) = x(:,k) + xp(:,k)*dt;
    
    % n�chster Wert der Ausgangsgr��e y
    y(:,k+1) = C*x(:,k+1) + D*u(k+1);
end

%--------------------------------------------------------------------------
% Ergebnis plotten
%--------------------------------------------------------------------------
figure; 
plot(t,y,'m'); grid on; hold on;
if length(t)<50   % Marker setzen, falls weniger als 50 St�tzstellen
    plot(t,y,'m^')
end
title('magenta=Euler');
xlabel('Time (seconds)');
ylabel('Amplitude');

%==========================================================================
% die Probe erfolgt wie bei Variante a)
