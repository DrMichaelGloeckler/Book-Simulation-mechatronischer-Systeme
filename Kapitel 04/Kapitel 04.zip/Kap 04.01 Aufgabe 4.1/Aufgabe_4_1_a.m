% Euler-Integration der Sprungantwort eines PT1-Gliedes
% siehe: Aufgabe 4.1
%
% In diesem Beispiel werden alle Funktionen und Befehle direkt aus einer 
% Datei heraus aufgerufen.
% Variante a) direkte Berechnung des Sch�tzwertes des Ausgangssignals y
%             nach der Gleichung (4.93)
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

%--------------------------------------------------------------------------
% Systemparameter festlegen
%--------------------------------------------------------------------------
T1 = 0.020;     % PT1-Zeitkonstante = 20ms

%==========================================================================
% Euler-Integration
%==========================================================================
dt = 0.01;          % Schrittweite dt
t_end = 0.2;        % Simulationszeitdauer
t = (0:dt:t_end);   % Zeit-Vektor

%--------------------------------------------------------------------------
% Felder initialisieren (nur zwecks Laufzeitoptimierung)
%--------------------------------------------------------------------------
u = zeros(1,length(t));
y = zeros(1,length(t));
yp= zeros(1,length(t));
dy= zeros(1,length(t));
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Anfangswerte zum Zeitpunkt t=0 setzen
%--------------------------------------------------------------------------
t(1) = 0;
y(1) = 0;                             % Anfangswert des Ausgangs = 0
u(1) = 1;                             % Eingang = Sprungfunktion = 1 
% erste Ableitung l��t sich direkt aus der Differentialgleichung berechnen
% (Gl.(II)): yp = (u-y)/T1;
yp(1) = ( u(1) - y(1) ) / T1;


%--------------------------------------------------------------------------
% F�r alle weiteren Zeitschritte werden die Werte rekursiv berechnet
%--------------------------------------------------------------------------
for k=1:length(t)-1
    % aktueller Zeitpunkt t(k)
    
    % n�chster Eingangswert (hier: Einheitssprung=1)
    u(k+1) = 1;
    
    % aktueller Ausgangswert aus Euler-Integration mit
    % y(k+1) = y(k) + {dy/dt}(k) * dt
    y(k+1) = y(k) + yp(k)*dt;
    
    % Ableitung dy/dt(k+1) f. PT1-Glied bilden
    yp(k+1) = ( u(k+1) - y(k+1) ) / T1;
    
end

%--------------------------------------------------------------------------
% Ergebnis plotten
%--------------------------------------------------------------------------
figure; 
plot(t,y,'m'); grid on; hold on;
if length(t)<50   % Marker setzen, falls weniger als 50 St�tzstellen
    plot(t,y,'m^')
end

%==========================================================================
% 1.Probe: Vergleich mit numerisch berechneter Sprungantwort
%==========================================================================
%--------------------------------------------------------------------------
% �bertragungsfunktion G(s) = num(s)/den(s) = 1 / (T1*s + 1)
%--------------------------------------------------------------------------
num = 1;
den = [T1 1];

% Sprungantwort mit MATLAB Funktion (aus: Control-Toolbox)
step(num,den);

%==========================================================================
% 2.Probe: Vergleich mit analytischer L�sung der Differentialgleichung 
%==========================================================================
%--------------------------------------------------------------------------
% analytische L�sung (siehe: separate Dokumentation)
%--------------------------------------------------------------------------
y_analyt = 1-exp(-t/T1);       % 
plot(t,y_analyt,'rs'); grid on; 
title('magenta=Euler, blau=step(), rot=analytische L�sung');

