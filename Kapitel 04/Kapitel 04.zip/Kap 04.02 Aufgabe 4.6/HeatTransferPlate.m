%HeatTransferPlate
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

disp('% Beispiel: Temperaturverteilung in einer ebenen Platte. ');
disp('% Sie hat anfangs �berall eine Temperatur von 20�C. ');
disp('% Zum Zeitpunkt t=0 wird die Temperatur an einem Rand (bei x=0) ');
disp('% auf 40�C erh�ht und konstant gehalten. Die Temperatur an den ');
disp('% �brigen R�ndern betr�gt 20�C. ');
disp(' ');
disp('%  dT       [ d�T   d�T ] ');
disp('%  -- = a * [ --- + --- ] ');
disp('%  dt       [ dx�   dy� ] ');
disp(' ');
disp('% Temperatur T ');
disp('% Zeit t ');
disp('% Wegkoordinaten x, y ');
disp(' ');
disp('% Berechnung mittels R�ckw�rtsdifferential. Die Temperataurverteilung  ');
disp('% wird in der Unterfunktion platePDE() gerechnet. ');
disp('');
disp('');

%--------------------------------------------------------------------------
% Vorgabewerte
%--------------------------------------------------------------------------
lx = 0.1;           % Kantenl�nge 0.1m
ly = 0.15;          % Kantenl�nge 0.15m
a = 1e-4;           % Konstante [m2/s]

%--------------------------------------------------------------------------
% St�tzpunkte in t-Richtung (Zeit)
%--------------------------------------------------------------------------
Tsim = 10;                  % Simulationszeitdauer [s]
npts = 100;                 % Anzahl Zeit-St�tzpunkte
t  = linspace(0,Tsim,npts); % Simulationszeitraster
dt = t(2)-t(1);

% a*dt/dz^2 <= 0.5          % Wegschrittweite mit Faustformel bestimmen
dx = sqrt(2*a*dt)*2;
dy = dx;

%--------------------------------------------------------------------------
% St�tzpunkte in x- und y-Richtung
%--------------------------------------------------------------------------
x  = (0:dx:lx);
y  = (0:dy:ly);

%--------------------------------------------------------------------------
% Temperatur-Array vorbelegen
% T[ Zeit, x-Koordinate, y-Koordinate ]
%--------------------------------------------------------------------------
T = zeros(length(t),length(x),length(y));
sizeT = [ length(x) length(y) ];

%--------------------------------------------------------------------------
% Anfangswerte t=0
%--------------------------------------------------------------------------
% 20 �C Anfangstemperatur in der ganzen Platte, ausser bei x=0
T0 = 20;                    % 20 �C Anfangstemperatur im ganzen Stab
TE = 40;                    % 40 �C Anfangstemperatur ganz aussen
T(1,2:length(x),:) = T0 * ones(length(x)-1,length(y));

% TE an einer Seite der PLatte bei x=0
T(1,1,:) = TE * ones(length(y),1);  

%--------------------------------------------------------------------------
% Randbedingungen bzw. Randwerte
%--------------------------------------------------------------------------
% Randbedingung bei y=0, t=0...tEnd: dort ebenfalls T=T0
T(:,:,1) = T0 * ones(length(t),length(x));       
% Randbedingung bei y=ly, t=0...tEnd: dort ebenfalls T=T0
T(:,:,length(y)) = T0 * ones(length(t),length(x));       


figure; hold off; grid on;
%==========================================================================
% Berechnungsschleifen
%==========================================================================
for it=1:length(t)-1
    % Schleife �ber alle Zeitst�tzpunkte
    
    % die Temperaturverteilung f�r den jeweiligen Zeitpunkt wird in einem
    % Unterfunktion berechnet
    T2D = platePDE(reshape(T(it,:,:),length(x),length(y)),a,x,y,dx,dt);
    T(it+1,:,:) = T2D;
   
    %----------------------------------------------------------------------
    % jeden Zeitschritt plotten
    %----------------------------------------------------------------------
    %T2D = reshape(T(it,:,:),length(x),length(y));
    surf(T2D); view(130,30);
    %[C,h] = contourf(T2D,15); colormap jet;
    drawnow;
end
title('r�umlich / zeitlicher Temperaturverlauf');
ylabel('x');
xlabel('y');
zlabel('T [�C]');

figure;
contourf(T2D,15); colormap jet;
xlabel('St�tzpunkt y [-]'); 
ylabel('St�tzpunkt x [-]'); 
title('Temperaturverteilung zum Zeitpunkt t=tEnd');
