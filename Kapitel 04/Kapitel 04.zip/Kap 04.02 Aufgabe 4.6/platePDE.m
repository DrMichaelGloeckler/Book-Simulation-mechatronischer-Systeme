function Tnew = platePDE(T,a,x,y,dx,dt)
%platePDE
%

% hiermit werden: size(Tnew) definiert,
%                 Randwerte bei ix=1, iy=1, ix=length(x) und iy=length(y)
%                 vom letzten Aufruf �bernommen. 
Tnew = T;

for ix=2:length(x)-1
    for iy=2:length(y)-1        
        Tnew(ix,iy) = T(ix,iy) + a*dt/dx^2 * ...
                        ( T(ix+1,iy) + T(ix-1,iy) ...
                           + T(ix,iy+1) + T(ix,iy-1) ...
                            - 4*T(ix,iy) );
    end
end

