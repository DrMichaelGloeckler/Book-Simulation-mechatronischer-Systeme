% Integration mit Runge-Kutta-Verfahren 4.Ordnung der Sprungantwort eines 
% PT2-Gliedes
% siehe: Aufgabe 4.4
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

%==========================================================================
% Integrationsparameter
%==========================================================================
t0 = 0;                     % Anfangszeit
dt = 0.01;                  % Schrittweite 0.01s
tfinal = ceil(2.0/dt)*dt;   % Simulationszeitdauer 2s
t = (t0:dt:tfinal);    

%--------------------------------------------------------------------------
% Systemparameter der Strecke festlegen
% (wird an dieser Stelle gebraucht, um die Anfangswerte des Zustandsvektors
%  x aus den Anfangswerten des Ausgangssignals y zu berechnen)
%--------------------------------------------------------------------------
T1 = 0.050;     % Zeitkonstante 50ms
T2 = 0.1;       % Zeitkonstante 100ms

%--------------------------------------------------------------------------
%   Eingangssignal-Vektor: Einheitssprung
%--------------------------------------------------------------------------
u = ones(1,length(t));

%--------------------------------------------------------------------------
%   Startwert(e) f�r y
%--------------------------------------------------------------------------
y0 = [ 0 ;    % Anfangswert dy/dt des Ausgangs
       0 ];   % Anfangswert y des Ausgangs

%--------------------------------------------------------------------------
%   daraus die Startwert(e) f�r x berechnen nach Gl.(3.83)
%--------------------------------------------------------------------------
x0 = [(T2*T2) ;
      (T2*T2)] .* y0;

%--------------------------------------------------------------------------
% Runge-Kutta-Integrationsverfahren aufrufen
%--------------------------------------------------------------------------
[x,y] = myRK4(@pt2_func,t,u,x0);

%--------------------------------------------------------------------------
% Ergebnis plotten
%--------------------------------------------------------------------------
figure; 
plot(t,y(1,:),'m'); grid on; hold on; title('magenta:Runge-Kutta 4.ord.');
if length(t)<50   % Marker setzen, falls weniger als 50 St�tzstellen
    plot(t,y(1,:),'m^')
end


%==========================================================================
% Probe: Vergleich mit numerisch berechneter Sprungantwort
%==========================================================================
%--------------------------------------------------------------------------
% �bertragungsfunktion G(s) = num(s)/den(s) = 1 / ((T2*s)^2 + T1*s + 1)
%--------------------------------------------------------------------------
num = 1;
den = [T2*T2 T1 1];

% Sprungantwort mit MATLAB Funktion (aus: Control-Toolbox)
step(num,den); grid on;
title(['magenta=Runge-Kutta 4.ord., blau=step(); Schrittweite=' num2str(dt) '[s]']);
