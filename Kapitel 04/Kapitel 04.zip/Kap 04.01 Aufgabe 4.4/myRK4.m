function [x,y] = myRK4(f,t,u,x0)
%myRK4    Funktion zur Integration der Differentialgleichung 
%         dy/dt = f(t,y(t)) mit dem Runge-Kutta-Verfahren 4.Ordnung
%         Die zu integrierende Funktion f muss in der Form 
%         [dx,y] = f(x,u) vorliegen
%
%   f   = Verweis (function handle) auf die Differentialgleichung y' = f(x,y(x))
%   t   = [t0 t0+dt ... tfinal] [s]
%   u   = Eingangssignal u(t), muss f�r jeden Zeitschritt gegeben sein
%   x0  = x(t0)
%   x   = Zustandsvektor
%   y   = Ausgangssignal
%   dx  = Ableitung des Zustandsvektors nach der Zeit = dx/dt
%
% Literatur: /Bronstein 20.Aufl. 1979 Kap.7.1.2.9.1, S.808/
% 

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

%--------------------------------------------------------------------------
% Eingabeparameter pr�fen
%--------------------------------------------------------------------------
if nargin<4
    error('not enough input arguments');
elseif nargin>4
    error('too many input arguments');
end
if length(u)~= length(t)
    error('t und u m�ssen gleiche L�nge haben');
end

% Felder initialisieren (nur zur Rechenzeitoptimierung)
x  = zeros(length(x0),length(t));
xp = zeros(length(x0),length(t));
y  = zeros(1,length(t));


%==========================================================================
% hier beginnt die eigentliche Berechnung
%==========================================================================
%--------------------------------------------------------------------------
% Anfangswerte zum Zeitpunkt t0
%--------------------------------------------------------------------------
x(:,1) = x0;                		 % Anfangswert des Ausgangs = 0

%--------------------------------------------------------------------------
% F�r alle weiteren Zeitschritte werden die Werte rekursiv berechnet
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
% F�r alle weiteren Zeitschritte werden die Werte rekursiv berechnet
%--------------------------------------------------------------------------
for k=1:length(t)-1
    % aktueller Zeitpunkt t(k), aktueller Eingangswert x(k),
    % aktuelle Ableitung dx/dt
    [xp(:,k),y(k)] = f( x(:,k), u(k) );
    
    % aktueller Zeitschritt dt; es k�nnen auch variable Schrittweiten
    % verwendet werden.
    dt = t(k+1) - t(k);  
    
    % Hilfsgr��en
    K1 = f( x(:,k),         u(:,k) );
    K2 = f( x(:,k)+dt/2*K1, u(:,k)+dt/2 );
    K3 = f( x(:,k)+dt/2*K2, u(:,k)+dt/2 );
    K4 = f( x(:,k)+dt*K3,   u(:,k)+dt );
    
    % naechster Zeitschritt nach Runge-Kutta 4.Ordnung mit
    x(:,k+1) = x(:,k) + dt/6 * (K1 + 2*K2 + 2*K3 + K4);
    
end
%--------------------------------------------------------------------------
% Ausgangswert y am letzten Zeitschritt berechnen
%--------------------------------------------------------------------------
k=length(t);
    % aktueller Zeitpunkt t(k), aktueller Eingangswert x(k),
    % aktuelle Ableitung dx/dt
    [xp(:,k),y(k)] = f( x(:,k), u(k) );

return;
