% Aufgabe 11.4
%--------------------------------------------------------------------------
% In diesem Beispiel wird eine Regelstrecke, bestehend aus zwei PT1-Gliedern
% mit einem PI-Regler betrieben. 
% Die Komponenten werden zun�chst als separate System-Objekte modelliert,
% anschlie�end hintereinander geschaltet. Abschlie�end wird der Regelkreis
% geschlossen. Vom offenen und vom geschlossenen Regelkreis werden Bodedia-
% gramme erstellt. 
%--------------------------------------------------------------------------
clear all;
clc;

% Die Regelstrecke besteht aus 2 PT1-Gliedern.
Gs1 = tf( 1, [0.0005 1]);
Gs2 = tf( 1, [0.0025 1]);

% Nun werden die beiden Teilsysteme Gs1 und Gs2 zur
% Gesamtstrecke Gs zusammen gesetzt.
Gs = series(Gs1,Gs2);

% Die �bertragungsfunktion des PI-Reglers ist
Tn  = 0.0025;
Kp  = 3.0;
Gpi = tf( [Kp*Tn Kp], [Tn 0] );

% Der offene Regelkreis setzt sich aus dem PI-Regler und 
% der Strecke zusammen
G0  = series(Gpi,Gs);

% Abschlie�end wird der Regelkreis geschlossen. 
% MATLAB verlangt die Angabe einer �bertragungsfunktion 
% im R�ckf�hrzweig. In unserem Fall ist das G(s) = 1 = 1/1
G   = feedback( G0, tf(1,1) );

% Bodediagramm der Gesamtstrecke in einem neuen Fenster
bode(G); 
grid on;
title(['geschlossener Regelkreis G mit P-Regler, Kp = ' num2str(Kp)]);
