function [ratio] = dB2ratio(db)
%dB2ratio  Umwandlung Dezibel -> Verhaeltnis
%
%	[ratio] = dB2ratio(db)
%
%	ratio = Verhaeltnis
%	db    = Verhaeltnis in [dB]

nargs = nargin;

if (nargs==1),

  ratio = 10.0.^(db/20.0);

else
  error('Wrong number of input arguments.');

end

return;