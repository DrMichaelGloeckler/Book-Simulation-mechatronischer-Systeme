% Aufgabe 11.5
%--------------------------------------------------------------------------
% Eine Regelstrecke vom Typ PT2 wird mit einem P-Regler betrieben. 
% Gesucht sind die �bertragungsfunktion des geschlossenen Regelkreises und
% der Frequenzgang in Form eines Bode-Diagramms.
%--------------------------------------------------------------------------
clear all;
clc;

% Die Regelstrecke besteht aus einem PT2-Glied.
f0 = 20;                    % Eigenfrequenz [Hz]
D  = 0.6;                   % D�mpfungsma�
w0 = 2*pi*f0;               % Kennkreisfrequenz [1/s]
Kp = 5;                     % Verst�rkung des Reglers

Gs = tf( 1, [1/w0/w0, 2*D/w0, 1]);
Gr = tf( Kp, 1);

% Der offene Regelkreis setzt sich aus dem P-Regler und 
% der Strecke zusammen
G0  = series(Gr,Gs);

% Bodediagramm des offenen Regelkreises
bode(G0); 
grid on;
title('offener Regelkreis G mit P-Regler');

% Abschlie�end wird der Regelkreis geschlossen. 
% MATLAB verlangt die Angabe einer �bertragungsfunktion 
% im R�ckf�hrzweig. In unserem Fall ist das G(s) = 1 = 1/1
G   = feedback( G0, tf(1,1) );

% Bodediagramm des geschlossenen Regelkreises in einem neuen Fenster
figure;
bode(G); 
grid on;
title('geschlossener Regelkreis G mit P-Regler');
