% Aufgabe 11.3
%
%           sin(t)
% y(t) = ------------
%        cos(t)^2 + 2
%
clear;
clc

%__________________________________________________________________________
% 
% Vorbereitung
%__________________________________________________________________________
% Vektor f�r die Zeit t anlegen von 0 bis 10s
% die Schrittweite wird frei gew�hlt, hier: 0.01 s 
t = (0:0.01:10);

%--------------------------------------------------------------------------
% y berechnen
% der . sorgt f�r eine elementweise Berechnung
y = sin(t) ./ ( cos(t).*cos(t) + 2);

%--------------------------------------------------------------------------
plot(t,y);
    xlabel('Zeit [s]');
    ylabel('y');
    title('y(t) = sin(t) / ( cos(t)^2 + 2)');
    grid on;

%__________________________________________________________________________
%
% Teilaufgabe 1: Berechnung der numerischen Ableitung nach der Zeit
%__________________________________________________________________________
yp = gradient(y)./gradient(t);
% Erl�uterung: 
% Die Funktion gradient(y) bildet den Gradienten dy/dn. n bezeichnet die
% St�tzstellen, an denen y vorliegt. 
% Dementsprechend bildet die Funktion gradient(t) den Gradienten dt/dn. 
% Der Quotient beider ist dann (dy/dn)/(dt/dn) = dy/dt gleich der Ableitung 
% von y nach t. 

%--------------------------------------------------------------------------
figure;
plot(t,yp);
    xlabel('Zeit [s]');
    ylabel('dy/dt');
    title('Ableitung von y(t) nach der Zeit');
    grid on;

%__________________________________________________________________________
%
% Teilaufgabe 2: numerische Berechnung des Integrals nach der Zeit
%__________________________________________________________________________
yi(1) = 0;              % Anfangswert des Intregrals = 0
for n = 2:length(t)
    yi(n) = trapz(t(1:n),y(1:n));
end
% Erl�uterung: 
% Der Aufruf von trapz(t,y) w�rde nur einen einzigen Wert liefern; n�mlich 
% den Wert des gesamten Integrals zwischen 0 und 10 s. 
% M�chte man dagegen den Verlauf des Intergals ausgeben, muss immer von 0 
% bis zu jedem einzelnen St�tzpunkt integriert werden. 

%--------------------------------------------------------------------------
figure;
plot(t,yi);
    xlabel('Zeit [s]');
    ylabel('Integral(y dt)');
    title('Integral von y(t) �ber der Zeit');
    grid on;
