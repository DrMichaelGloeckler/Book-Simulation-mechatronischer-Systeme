%==========================================================================
% Zeitdiskrete Simulation der Sprungantwort eines PT1-Gliedes
%
%            1
%  G(s) = --------
%         T1*s + 1
%
%==========================================================================
clear;          % Workspace aufr�umen
clc;            % Command Window l�schen

% Parameter setzen
T1  = 0.1;      % Zeitkonstante [s]
Tab = 0.05;     % Abtastzeit [s]

% Koeffizienten der zeitkontinunierlichen �bertragungsfunktion G(s)
num = 1;
den = [T1, 1];

% Diskretisierung => Koeffizienten der zeitdiskreten �bertragungsfunktion G(z)
[numd,dend] = c2dm(num,den,Tab,'zoh');

% Sprungantwort der zeitdiskreten �bertragungsfunktion G(z)
dstep(numd,dend,25);
grid on;
