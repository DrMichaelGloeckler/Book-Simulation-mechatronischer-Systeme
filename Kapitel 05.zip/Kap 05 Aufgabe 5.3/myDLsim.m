function y = myDLsim(numd,dend,u)
%myDLsim  Funktion zur zeitdiskreten Simulation eines linearen �ber-
%         tragungsgliedes mit der z-�bertragungsfunktion G(z) = numd/dend
%
%    y = myDLsim(numd,dend,u)
%
%    numd = Koeffizienten des Z�hlers von G(z): [d0, d1, d2, ...]
%    dend = Koeffizienten des Nenners von G(z): [c0, c1, c2, ...]
%    u    = Eingangsgr��e
%    y    = Ausgangsgr��e
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================


numOrd = length(numd);      % Ordnung im Z�hler bestimmen
denOrd = length(dend);      % Ordnung im Nenner bestimmen
Ord = max(numOrd,denOrd);

kMax = length(u) + Ord;

% Vorlauf f�r t<0 anlegen (wird sp�ter wieder abgeschnitten)
y(1:Ord) = 0;           % y = 0 f�r t<0 
u = [ zeros(1,Ord),u];  % u = 0 f�r t<0 

% Simulation f�r t>=0 nach Gleichung (5.134)
for k = Ord+1:kMax
    % Z�hlerterme
    y(k) = numd(1)*u(k);
    for in = 1:numOrd-1
        y(k) = y(k) + numd(in+1)*u(k-in);
    end
    % Nennerterme
    for id = 1:denOrd-1
        y(k) = y(k) - dend(id+1)*y(k-id);
    end
end

% Vorlauf wieder abgeschneiden und durch c0 teilen
y = y(Ord+1:length(y))/dend(1);

end
