% Zeitdiskrete Simulation linearer �bertragungsglieder 
% siehe: Aufgabe 5.3
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

%==========================================================================
clear;          % Workspace aufr�umen
clc;            % Command Window l�schen

T1  = 20e-3;     % Zeitkonstante [s]
Tab = 5e-3;

% -------------------------------------------------------------------------
% Eingangsgr��e u: Sprung von 0 auf 1 nach 11 Zeitschritten
% -------------------------------------------------------------------------
u(1:10) = 0;
u(11:30) = 1;
% u(1:30) = 1;

% -------------------------------------------------------------------------
% zeitkontinuierliche �bertragungsfunktion G(s) = num/den
% -------------------------------------------------------------------------
num = 1;
den = [T1, 1];

% -------------------------------------------------------------------------
% zeitdiskrete �bertragungsfunktion G(z) = numd/dend
% -------------------------------------------------------------------------
[numd,dend] = c2dm(num,den,Tab,'zoh');

% -------------------------------------------------------------------------
% Aufruf der Funktion f�r die zeitdiskrete Simulation
% -------------------------------------------------------------------------
y = myDLsim(numd,dend,u);

% -------------------------------------------------------------------------
% Ergebnis der Simulation ausgeben
% -------------------------------------------------------------------------
stairs(y,'k');
grid on;
xlabel('Abtastschritt k');
ylabel('Ausgangsgr��e y');
