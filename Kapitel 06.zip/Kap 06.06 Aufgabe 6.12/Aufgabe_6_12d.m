% Aufgabe 6.12 d)
% Lineariserung des nichtlinearen Modells an einem Arbeitspunkt. 
%
%  u(t)  |-------------------|  y(t)
% ------>| PunktpendelModell |------>
%        |-------------------|
%
%

% �bergabeparameter von linmod: 
%   Modellname
%   Arbeitspunkt = [Zustandsgr��e und erste Ableitung am Arbeitspunkt]
%   Eingangssignal (hier: = 0)

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

%--------------------------------------------------------------------------
% Parameter laden
%--------------------------------------------------------------------------
PunktpendelParameter;

%--------------------------------------------------------------------------
% Linearisierung am Arbeitspunkt x = [60� 0�/s], u=0
% So aufgerufen liefert die Funktion Z�hler und Nenner der
% �bertragungsfunktion
[num,den] = linmod('PunktpendelModell',[60*pi/180 0],0);
% in Standardform bringen
num = num/den(length(den));
den = den/den(length(den));
    disp(['Z�hlerkoeffizienten von G(s): ' num2str(num)]);
    disp(['Nennerkoeffizienten von G(s): ' num2str(den)]);

% Falls das Modell 2.Ordnung ist
if length(num)<=3 && length(den)==3
    % Parameter des linearisierten Ersatzmodells: Eigenfrequenz & D�mpfung
	disp(['Parameter des linearisierten Modells: ']);

    f0_lin = 1/sqrt(den(1))/2/pi; 
        disp(['f0(linearisiert) = ' num2str(f0_lin) ' [Hz]']);
    D_lin  = den(2)/2*(f0_lin*2*pi); 
        disp([' D(linearisiert) = ' num2str(D_lin)]);
end
