% Parameter f�r die Aufgabe 6.12
% siehe: Aufgabe_6_12b.slx, PunktpendelModell.mdl

m = 2.0;        % Masse [kg]
r = 0.5;        % Radius [m]
mue_r = 1e-1;   % viskoser Reibkoeffizient [Nm.s/rad]
Mr0   = 0.0;    % Haftreibmoment [Nm]
g = 9.81;       % Erdbeschleunigung [m/s/s]

w0 = 0.0;       % Anfangswinkelgeschw. [rad/s]
alpha0 = 30*pi/180;   % Anfangswinkel [rad] [z.B.: 30deg, 60deg, 90deg}

% f0 [Hz] (linearisiert, ohne Reibung)
f0 = sqrt(g/r) /2/pi;
