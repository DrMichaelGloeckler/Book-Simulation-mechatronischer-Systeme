% Aufgabe 6.6
% Beispiel f�r die Berechnung des Bodediagramms aus gemessenen Signal-
% verl�ufen. Die Anregung erfolgt durch ein Rauschsignal.
%
%  u(t)  |---------|  y(t)
% ------>|    G    |------>
%        |---------|
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

% Abtastzeit 1ms
Tab = 1e-3;

%--------------------------------------------------------------------------
% Eingangssignalfolge u
% Die Funktion erzeugt ein Zufallssignal im Amplitudenbereich von -1...+1
%--------------------------------------------------------------------------
len = 2000;                         % 2000 Messpunkte
time = Tab * (0:len-1);             % Zeitvektor: 2000 Zeitwerte im Raster der Abtastzeit
u = 2.0*(rand(size(time))-0.5);     % liefert Zufallswerte zwischen -1...+1

%--------------------------------------------------------------------------
% Beispiel-Strecke 4.Ordnung (PDT4)
% f1 = 20; D1 = 0.25; w1 = 2*pi*f1
% f2 = 40; D2 = 0.15; w2 = 2*pi*f2
%                    1                         2*D1/w1*s + 1
% G(s) = ---------------------------  * ---------------------------  
%        1/w1/w1*s^2 + 2*D1/w1*s + 1    1/w2/w2*s^2 + 2*D2/w2*s + 1
%
%--------------------------------------------------------------------------
num = [0.000397887357729738    1.0000];
den = [1.00253732955902e-09,8.81877894657799e-08,8.07403182149879e-05,0.00437676093502712,1];
    
%--------------------------------------------------------------------------
% Die Eingangssignalfolge wird auf die Strecke gegeben und das Ergebnis 
% geplottet
%--------------------------------------------------------------------------
[y,x] = lsim(num,den,u,time);
    figure; plot(time,u); hold on; plot(time,y,'r');
    xlabel('Zeit [s]'); ylabel('u und y'); grid on;
    title('Eingangs- und Ausgangsgr��e');

%--------------------------------------------------------------------------
% nun folgt die Frequenzganganalyse
%--------------------------------------------------------------------------
[G,ampl,phase,freq]=sigbode(u,y,Tab,len,'hamming');
    figure;
    subplot(2,1,1);
    semilogx(freq,ampl); grid on;
    xlabel('Frequenz [Hz]'); ylabel('Amplitude [dB]');
    title('Bode-Diagramm');
    subplot(2,1,2);
    semilogx(freq,phase); grid on;
    xlabel('Frequenz [Hz]'); ylabel('Phase [deg]');


