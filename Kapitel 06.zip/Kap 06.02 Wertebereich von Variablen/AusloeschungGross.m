% Skript zum Testen von Ausl�schung bei gro�en Zahlenwerten
clear;
clc;

for exponent = 0:20
x = 10^exponent;
number = x - 1.0; % Klammerausdruck
ergebnis = x - number;
disp(['x-(x-10^' num2str(exponent) ') = ' num2str(ergebnis)]);
end
