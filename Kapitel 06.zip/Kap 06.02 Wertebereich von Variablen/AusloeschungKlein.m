% Skript zum Testen von Ausl�schung bei kleinen Zahlenwerten
clear;
clc;

for exponent = 0:20
x = 10^-exponent;
number = 1.0-x; % Klammerausdruck
ergebnis = 1.0 - number;
disp(['1-(1-10^-' num2str(exponent) ') = ' num2str(ergebnis)]);
end
