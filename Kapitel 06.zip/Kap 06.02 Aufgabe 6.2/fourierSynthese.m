function y = fourierSynthese(a,b,freq,t)
%fourierSynthese    Rekonstruktion eines Signals y(t) mittels Fouriersynthese
%                   y = a(1)/2 + Summe{ a(i) * cos( omega(i)*t)
%                                      + b(i) * sin( omega(i)*t)  }; i=2...
%                   f�r alle Frequenzen omega = 2*pi*freq.
%
%   y = fourierSynthese(a,b,freq,t);
%
%       a    = Fourier-Koeffizient 
%       b    = Fourier-Koeffizient 
%       freq = Frequenzen [Hz]
%       t    = Zeit 0...Tend [s]
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

%   =======================================================================
%   24.07.2008 Dr.M.Gloeckler
%   14.09.2008 Fourierkoeffizient a(1) wie in der Literatur,
%   =======================================================================

%--------------------------------------------------------------------------
% ggf. verschieden lange Parameters�tze angleichen
%--------------------------------------------------------------------------
if length(a)~=length(b)
    len = min(max(length(a),length(b)),length(freq));
    % ggf. Koeffizienten mit Nullen auff�llen
    a   = zeros(len,1) + colvect(a);
    b   = zeros(len,1) + colvect(b);
end

%--------------------------------------------------------------------------
% Rekonstruktion mittels Fourier-Synthese
%--------------------------------------------------------------------------
y = a(1)/2;
for i=2:length(freq)
	y = y + a(i)*cos(2*pi*freq(i)*t) + b(i)*sin(2*pi*freq(i)*t);
end

return;