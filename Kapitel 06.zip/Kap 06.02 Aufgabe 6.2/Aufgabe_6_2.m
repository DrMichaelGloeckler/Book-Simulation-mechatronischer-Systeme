% Beispiel zur Spektralanalyse
% Rechtecksignal mit einer Periodendauer von 50ms, das zwischen den Ampli-
% tudenwerten +1 und +3 wechselt. 

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear all;
clc;


%--------------------------------------------------------------------------
% Zeit
%--------------------------------------------------------------------------
Tab = 1e-3;     % Abtastzeit 1ms
t = (0:Tab:5);  % 0...5s

%--------------------------------------------------------------------------
% Frequenz [Hz]
%--------------------------------------------------------------------------
f1 = 20.0;
Tp = 1/f1/2;    % halbe Periodendauer
Np = round(Tp/Tab);

%--------------------------------------------------------------------------
% Zeitverlauf
%--------------------------------------------------------------------------
y_offset = 2.0;
pattern = [-ones(Np,1); ones(Np,1) ] + y_offset*ones(2*Np,1);
y = zeros(length(t),1);
for i=1:floor(length(t)/length(pattern))
    y(1+(i-1)*length(pattern):i*length(pattern)) = pattern;
end

figure;
plot(t,y); grid on;
    xlabel('time [s]'); 
    ylabel('ampl'); 
    title('original square wave signal [0 ... 0.5s]')
    axis([0 0.5 0.5 3.5]);


%--------------------------------------------------------------------------
% FFT mit sigFFT
%--------------------------------------------------------------------------
[Y,ampl,phase,freq,a,b]=sigFFT(y,Tab,length(y),'none');

%--------------------------------------------------------------------------
% Rekonstruktion mit den Fourier-Koeffizienten als Summe aller Frequenz-
% anteile in der Funktion fourierSynthese().
%--------------------------------------------------------------------------
yf = fourierSynthese(a,b,freq,t);

%--------------------------------------------------------------------------
% Ergebnis plotten
%--------------------------------------------------------------------------
figure; 
plot(t,yf,'b'); 
hold on; grid on;
plot(t,yf,'b+'); 
plot(t,y,'r'); 
    xlabel('Zeit [s]'); 
    ylabel('Amplitude'); 
    title('urspr�ngliches (rot) u. rekonstruiertes Signal (blau) [0 ... 0.5s]')
    xlim([0 0.5]);
    