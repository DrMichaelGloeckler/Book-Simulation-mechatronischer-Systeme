% Aufgabe 6.1
% Beispiel zur Spektralanalyse
% 2 Sinusschwingungen unterschiedlicher Frequenz werden zu einem Signal
% zusammen gesetzt. Anschlie�end erfolgt eine FFT-Analyse, um die
% Frequenzen und deren Amplituden zu bestimmen. 
% Als Probe wird das Signal aus den Fourrierkoeffizienten rekonstruiert.
% Beide m�ssen �bereinstimmen. 

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear all;
clc;

%--------------------------------------------------------------------------
% 1.Frequenz [Hz]
%--------------------------------------------------------------------------
f1 = 20.0;
w1 = 2*pi*f1;

%--------------------------------------------------------------------------
% 2.Frequenz [Hz]
%--------------------------------------------------------------------------
f2 = 50.0;
w2 = 2*pi*f2;

%--------------------------------------------------------------------------
% Zeit
%--------------------------------------------------------------------------
Tab = 1e-3;     % Abtastzeit 1ms
t = (0:Tab:5);  % 0...5s

%--------------------------------------------------------------------------
% Zeitverlauf als Summe beider Frequenzen mit Offset;
% 2.Frequenz Phasenversatz von pi/8
%--------------------------------------------------------------------------
y_offset = 2.0;
y = y_offset -0.5*cos( w1*t ) + 0.75*sin( w2*t +pi/8 );

figure;
plot(t,y); grid on;
    xlabel('Zeit [s]'); 
    ylabel('Amplitude'); 
    title('urspr�ngliches Signal [0 ... 0.5s]');
    xlim([0 0.5]);

    disp('plotte urspr�ngliches Signal');
    disp('weiter mit einer Taste...');
    pause;

%--------------------------------------------------------------------------
% schnelle Fourier-Transformation mit der selbst entwickelten Funktion sigFFT
%--------------------------------------------------------------------------
[Y,ampl,phase,freq,a,b]=sigFFT(y,Tab,length(y),'none');

    clc;
    disp('Amplitudenspektrum des urspr�nglichen Signals');
    disp('weiter mit einer Taste...');
    pause;


%--------------------------------------------------------------------------
% Rekonstruktion mit den Fourier-Koeffizienten nach Gl.(4.2.4)
% als Summe aller Frequenzanteile
%--------------------------------------------------------------------------
len = length(y);
yf=a(1)/2;
for i=2:len/2
    yf = yf + a(i)*cos(2*pi*freq(i)*t) + b(i)*sin(2*pi*freq(i)*t);
end

%--------------------------------------------------------------------------
% Ergebnis plotten
%--------------------------------------------------------------------------
figure; 
plot(t,yf,'b'); 
hold on; 
plot(t,yf,'b+'); 
plot(t,y,'r'); 
    xlabel('Zeit [s]'); 
    ylabel('Amplitude'); 
    title('urspr�ngliches (rot) u. rekonstruiertes Signal (blau) [0 ... 0.5s]');
    xlim([0 0.5]);
    clc;
    disp('Rekonstruktion des urspr�nglichen Signals aus den Fourrier-Koeffizienten');
