function [Y,ampl,phase,freq,a,b]=sigFFT(signal,tab,len,wndw)
%sigFFT  compute the FFT spectrum of a measured signal
%        FFT Spektrum eines gemessenen Signals
%
%   [Y,ampl,phase,freq,a,b]=sigFFT(signal,tab,len,wndw);
%
%   signal = signal to be analyzed
%            das zu analysierende Signal
%   tab  = sample time [s]
%          Abtastzeit [s]
%   len  = length of the fft sequence
%          L�nge der FFT [Abtastungen], s.a. fft.m
%   wndw = window used in fft invocation, default = {'hamming'}
%          Fensterfunktion
%   Y    = FFT(signal)
%   ampl = Amplitudengang [dB]
%   phase= Phasengang [dB]
%   freq = Frequenz [Hz]
%   a,b  = Fourierkoeffizienten
%
%   Rekonstruktion <fsignal> des Eingangssignals <signal> wie folgt:
%       fsignal = a(1)/2;
%       for i=2:len/2
%           fsignal = fsignal + a(i)*cos(2*pi*freq(i)*t) + b(i)*sin(2*pi*freq(i)*t);
%       end
%
% see also fourierSynthese fft
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

%   -----------------------------------------------------------------------
%   transform signal to column vectors if necessary
%   -----------------------------------------------------------------------
[nr,nc]=size(signal);
if nr==1 && nc>1
    signal = signal';
elseif nr>1 && nc>1
    error('only vector allowed');
end

%   -----------------------------------------------------------------------
%   FFT of input signal using hamming window
%   -----------------------------------------------------------------------
if strcmpi(wndw,'hamming')==1
    Y   = fft( hamming(length(signal)).*signal,len);

%   -----------------------------------------------------------------------
%   FFT of input signal using hanning window
%   -----------------------------------------------------------------------
elseif strcmpi(wndw,'hanning')==1
    Y   = fft( hanning(length(signal)).*signal,len);

%   -----------------------------------------------------------------------
%   FFT of input and output signal without window
%   -----------------------------------------------------------------------
else
    Y   = fft( signal,len);
end

%   -----------------------------------------------------------------------
%   Frequency [Hz]
%   nur bis zur halben Abtastfrequenz wegen Abtasttheorem von Shannon
%   -----------------------------------------------------------------------
freq = (0:floor(len/2))/len/tab;    % (len/2+1) Frequenzen von 0 ... 1/(2*tab) [Hz]

%   -----------------------------------------------------------------------
% Berechnung der Fourier-Koeffizienten 
% (nur f. den Bereich von 0 ... 1/(2*tab) [Hz] )
%   -----------------------------------------------------------------------
a =  2/len*real(Y(1:length(freq)));
b = -2/len*imag(Y(1:length(freq)));


%   -----------------------------------------------------------------------
%   Spektrum
%   -----------------------------------------------------------------------
ampl = [ 1/len*abs(Y(1)); ...               % Sonderbehandlung f. Gleichanteil ampl(1)
         2/len*abs(Y(2:length(freq))) ];
phase= 180/pi*angle(Y(1:length(freq)));     % 

figure;
stairs(freq,ampl(1:length(freq))); grid on;
xlabel('f [Hz]'); ylabel('A');
title('Amplitudenspektrum');
