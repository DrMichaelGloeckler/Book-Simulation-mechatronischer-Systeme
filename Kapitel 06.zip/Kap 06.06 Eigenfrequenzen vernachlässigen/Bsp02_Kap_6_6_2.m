% Kap. 6.6.2 Ordnungsreduktion
% Beispiel: Ordnungsreduktion mit Funktionen der Control System Toolbox
clear;
clc;

% Z�hlerkoeffizienten der �bertragungsfunktion
num = 0.067;	
% Nennerkoeffizienten der �bertragungsfunktion 
den = [6.416e-010 2.096e-007 0.000268 0.01974 1];
% �bertragungsfunktion aufstellen
sys = tf(num,den);
    disp('urspr�ngliche �bertragungsfunktion 4.Ordnung'); 
    sys
    
% Balancierte Form berechnen
[sysb,g] = balreal(sys);
% Kleine Werte von g kennzeichnen Zust�ndsvariablen, die vernachl�ssigt
% werden k�nnen. 

% Ermittle die Zust�ndsvariablen, bei denen g<0.001 ist 
elim = (g<0.001);
% Eliminiere Zust�ndsvariablen, bei denen g<0.001 ist 
sysr = modred(sysb,elim);

% Zeilen 21 bis 24 dienen nur der Umformung
[numr,denr] = ss2tf(sysr.a,sysr.b,sysr.c,sysr.d);
numr = numr/denr(length(denr));
denr = denr/denr(length(denr));

disp('vereinfachte �bertragungsfunktion 2.Ordnung'); 
tf(numr,denr)
