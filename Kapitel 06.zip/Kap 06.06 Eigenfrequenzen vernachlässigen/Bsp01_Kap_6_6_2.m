% Kap. 6.6.2 Ordnungsreduktion
% Beispiel: Eigenfrequenzen vernachl�ssigen
clear;
clc;

% Z�hlerkoeffizienten der �bertragungsfunktion
num = 0.067;	
% Nennerkoeffizienten der �bertragungsfunktion 
den = [6.416e-010 2.096e-007 0.000268 0.01974 1];
% �bertragungsfunktion aufstellen
sys = tf(num,den);
    disp('urspr�ngliche �bertragungsfunktion 4.Ordnung'); 
    sys
    
% Pole (= Nullstellen des Nenners) berechnen
P = pole(sys);
    disp('Pole (= Nullstellen des Nenners) der �bertragungsfunktion'); 
    P

% Z�hlerkoeffizienten der �bertragungsfunktion
numr = 0.067;	
% Nennerkoeffizienten der �bertragungsfunktion 
denr = [2.5329e-4 0.0191 1];

% �bertragungsfunktion aufstellen
sysr = tf(numr,denr);
    disp('vereinfachte �bertragungsfunktion 2.Ordnung'); 
    sysr

% Vergleich anhand der beiden Frequenzg�nge
bode(sys);
grid on; hold on;
bode(sysr);
