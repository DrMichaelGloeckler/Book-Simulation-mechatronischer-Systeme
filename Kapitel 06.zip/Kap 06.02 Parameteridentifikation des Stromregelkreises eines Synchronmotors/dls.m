function [numd,dend,p]=dls(y,u,ord)
%DLS	Direkte least-squares Identifikation fuer lineare diskrete Systeme.
%
%		    d0 + d1*z^-1 + ... + dn*z^-n
%	G(z) = ------------------------------
%		    1 + c1*z^-1 + ... + cn*z^-n
%
%	[numd,dend,p]=dls(y,u,ord)
%
%	y   = output-data
%	u   = input-data
%	ord = Systemordnung n
%	numd= Zaehlerpolynom
%	dend= Nennerpolynom
%	p   = Parametervektor = [c1...cn d1...dn]
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

%-----------------------------------------------
%	Anzahl d. tats. Schritte
%-----------------------------------------------
ny = length(y);
nu = length(u);
nsamples = min(ny,nu);

%-----------------------------------------------
%	Anzahl genutzer Schritte
%-----------------------------------------------
nused = nsamples - ord;			% = N
if nused<ord
  error('zu wenig Zeitschritte');
end

%-----------------------------------------------
%	Matrix M
%-----------------------------------------------
my = -y(1:nused) ;
mu =  u(1:nused) ;
for i=2:ord
  my = [ -y(i:nused+i-1) my ]; 
  mu = [  u(i:nused+i-1) mu ]; 
end
m = [ my mu ];

%-----------------------------------------------
%	Parametervektor p (Gl. 4.2.33)
%-----------------------------------------------
%p = inv(m'*m)*m'*y(ord+1:ord+nused);
p = (m'*m)\m'*y(ord+1:ord+nused);

%-----------------------------------------------
%	Uebertragungsfunktion G(z)
%-----------------------------------------------
numd = [0 p(ord+1:2*ord)' ];
dend = [1 p(1:ord)' ];


return;