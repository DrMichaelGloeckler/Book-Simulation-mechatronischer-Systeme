%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

%--------------------------------------------------------------------------
% Messdaten der Frequenzgangmessung laden
%--------------------------------------------------------------------------
load SRK.mat;

%--------------------------------------------------------------------------
% Frequenzgang rechnen
%--------------------------------------------------------------------------
[G_SRK,ampl_SRK,phase_SRK,freq_SRK]=sigbode(i_soll,i_ist,Tab,length(zeit),'hamming');

%--------------------------------------------------------------------------
% Bodediagramm plotten
%--------------------------------------------------------------------------
mybodeplot(freq_SRK,ampl_SRK,phase_SRK);

%--------------------------------------------------------------------------
%   Parameteridentifikation
%--------------------------------------------------------------------------
ordnung = 9;
[numd,dend,p] = dls(i_ist,i_soll,ordnung);

[mag,phase,W] = dbode(numd,dend,Tab);
mybodeplot( W/2/pi, ratio2dB(mag), phase, 'hold', 'r');
