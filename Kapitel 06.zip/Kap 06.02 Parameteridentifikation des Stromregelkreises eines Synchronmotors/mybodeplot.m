function mybodeplot(freq,ampl,phase,flag1,flag2)
%bodeplot  Bodeplot von Frequenz-, Amplituden- und Phasenverl�ufen.
% 
%   mybodeplot(freq,ampl,phase,flag);
%
%       freq  = Frequenzvektor [Hz]
%       ampl  = Amplitudenvektor [dB]
%       phase = Phasenvektor [deg]
%       flag  = 'hold': hold plot
%             = <string>: 
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014, 2016
%==========================================================================
if nargin>=4
    if ischar(flag1)==1
        if strcmpi(flag1,'hold')==1
            subplot(2,1,1); hold on; set(gca,'XScale','log');
            subplot(2,1,2); hold on; set(gca,'XScale','log');        
            titleStr = ' ';
        else
            titleStr = flag1;
            figure;
        end
    else
        figure;
        titleStr = ' ';
    end

    if nargin==5
        if ischar(flag2)==1
            formatStr = flag2;
        else
            formatStr = 'b';
        end
    else
        formatStr = 'b';
    end

else
    figure;
    titleStr = ' ';
    formatStr = 'b';
end

subplot(2,1,1);
semilogx(freq,ampl,formatStr); grid on;
xlabel('Frequenz [Hz]'); ylabel('Amplitude [dB]');
title(titleStr);

subplot(2,1,2);
semilogx(freq,phase,formatStr); grid on;
xlabel('Frequenz [Hz]'); ylabel('Phase [deg]');

return;