% Aufgabe 6.13
% Vernachl�ssigen bzw. Streichen von Zeitkonstanten
%
% In diesem Beispiel werden Zeitkonstanten im Z�hler und Nenner einer �ber- 
% tragungsfunktion gel�scht und und das Ergebnis in Form eines Bode-
% Diagramms ausgegen. 
% Hinweis: Control System Toolbox wird ben�tigt;
%          Alternativen siehe Zeilen 28,29 und 35-37
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen


% urspr�ngliche �bertragungungsfunktion aufstellen
num = [1 3 2];      % Koeffizienten des Z�hlers
den = [4 7 2 1];    % Koeffizienten des Nenners

sys = tf(num,den);  % System-Objekt erstellen

bode(sys);          % Bode-Diagramm ausgeben
% alternativ ohne Funktionen der Control System Toolbox: 
% bode(num,den);
grid on;            % Gitternetz einschalten
hold on;            % Plot einfrieren

[Z,G] = zero(sys);  % Nullstellen (Z) der urspr�nglichen �bertragungungsfunktion
P = pole(sys);      % Pole (P) der urspr�nglichen �bertragungungsfunktion
% alternativ ohne Funktionen der Control System Toolbox: 
% Z = roots(num)
% P = roots(den);

% Zeitkonstante den(1) im Nenner gestrichen
sys1 = tf(num,den(2:4));    % neues System-Objekt erstellen
bode(sys1);                 % Bode-Diagramm ausgeben 

% Zeitkonstante num(1)im Z�hler zus�tzlich gestrichen
sys2 = tf(num(2:3),den(2:4));	% neues System-Objekt erstellen
bode(sys2);                     % Bode-Diagramm ausgeben
% Bei dieser �bertragungungsfunktion betr�gt der Unterschied zur 
% urspr�nglichen �bertragungsfunktion weniger als 25� Phasenwinkel und 
% weniger als 5 dB Amplitude im Frequenzbereich bis 100 rad/s. 

% Zeitkonstante den(2) im Nenner zus�tzlich gestrichen
sys3 = tf(num(2:3),den(3:4));	% neues System-Objekt erstellen
bode(sys3);                     % Bode-Diagramm ausgeben

% Zeitkonstante num(2) im Z�hler zus�tzlich gestrichen
sys4 = tf(num(3:3),den(3:4));	% neues System-Objekt erstellen
bode(sys4);                     % Bode-Diagramm ausgeben
