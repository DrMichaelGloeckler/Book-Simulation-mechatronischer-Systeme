% Beispiel: Diskretisierung eines zeitkontinuierlichen PT2-Gliedes
%
%                     1
%  G(s) = -------------------------
%         1/w0^2*s^2 + 2*D/w0*s + 1
%

%==========================================================================
clear *                     % Workspace l�schen
clc;                        % Command Window l�schen

% Vorgabewerte
f0 = 20.0;                  % Eigenfrequenz [Hz]
D = 0.1;                    % D�mpfungsma�
% Zwischenrechnung
w0 = 2*pi*f0;               % Kennkreisfrequenz [1/s]

%_________________________________________________________________
% �bertragungsfunktion zeitkontinuierlich
num = 1;                    % Z�hler
den = [1/w0/w0, 2*D/w0, 1]; % Nenner
sysc = tf(num,den);         % Systemobjekt zeitkontinuierlich

% Sprungantwort simulieren (Index c = continuous)
[Yc,Tc] = step(sysc);       % Sprungantwort simulieren
    plot(Tc,Yc,'k');            % Ergebnis plotten
    xlabel('Zeit [s]');         % Achsenbeschriftung X-Achse
    ylabel('y');                % Achsenbeschriftung Y-Achse
    title('Sprungantwort PT_2: -zeitkont./+10ms/*33ms Abtastzeit');    % Titel
    grid on;                    % Gitternetz einschalten
    hold on;                    % Grafik einfrieren

%_________________________________________________________________
% �bertragungsfunktion zeitdiskret
Tab = 0.01;                 % Abtastzeit [s]
sysd1 = c2d(sysc,Tab);      % Systemobjekt zeitdiskret
% Sprungantwort simulieren (Index d = discrete)
[Yd1,Td1] = step(sysd1);
    plot(Td1,Yd1,'k+');
    axis([0 0.45 0 1.8]);       % Achsenskalierung

%_________________________________________________________________
% �bertragungsfunktion zeitdiskret
Tab = 0.033;                % Abtastzeit [s]
sysd2 = c2d(sysc,Tab);      % Systemobjekt zeitdiskret
% Sprungantwort simulieren (Index d = discrete)
[Yd2,Td2] = step(sysd2);
    plot(Td2,Yd2,'k*');