% Periodendauer der Eigenschwingung eines PT2-Systems aus seiner Sprung-
% antwort bestimmen. 
% siehe: Aufgabe 6.3
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================
clear *         % Workspace l�schen
clc;            % Command Window l�schen

%--------------------------------------------------------------------------
% Systemparameter festlegen
%--------------------------------------------------------------------------
num = 0.002857;                         % Z�hlerkoeffizient der �bertragungsfunktion
den = [2.58e-7, 1.418e-5, 0.006366];    % Nennerkoeffizienten der �bertragungsfunktion

%==========================================================================
% Systemobjekt erstellen
%==========================================================================
sys = tf(num,den);      % direkt auf Basis der �bertragungsfunktion

%--------------------------------------------------------------------------
% Sprungantwort simulieren
%--------------------------------------------------------------------------
step(sys);
grid on;

%==========================================================================
% Auswertung des Plots:
%   Zeitabstand zwischen zwei Schwingungsmaxima oder -minima:
%   T = 40 ms
%   => Eigenfrequenz f0 = 1/T = 25 Hz
%==========================================================================
