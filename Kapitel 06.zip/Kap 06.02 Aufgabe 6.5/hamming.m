function w = hamming(N)
%hamming    hamming window function
% 
%   w = hamming(N)
%
%       N = number of points
%       w = column vector 
%

n = (0:N-1)';
w = 0.53836 - 0.46164*cos(2*pi*n/(N-1));

return;