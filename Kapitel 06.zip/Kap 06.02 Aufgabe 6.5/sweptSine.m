function [y,t,f] = sweptSine(fStart,fEnd,T,Tab)
%sweptSine  Funktion berechnet den Ausgangswert y = sin( 2*pi*f*t ), wobei
%           die Frequenz f innerhalb der Zeit T von fStart bis fEnd an-
%           steigt. 
%
%   [y,t,f] = sweptSine(fStart,fEnd,T[,Tab]);
%       
%   fStart   = Anfangsfrequenz [Hz]
%   fEnd     = Endfrequenz [Hz]
%   T        = Zeitdauer f�r den sweep-Vorgang [s]
%   Tab      = Abtastzeit [s] (optional)
%              falls Tab nicht vorgegeben wird, wird ein Default-Wert von
%              Tab = 1/4/fEnd verwendet. 
%   y        = Ausgangssignal im Bereich -1...1
%   t        = �quidistanter Zeitvektor [s]
%   f        = Frequenzvektor [Hz]
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

if fStart > fEnd
    error('fStart must be < fEnd');
else
    if nargin==3
        Tab = 1/4/fEnd;
    else
        if Tab > 1/2/fEnd
            disp(['WARNING: sample time ' num2str(Tab) '[s] > 1/(Shannon frequency) = ' num2str(1/2/fEnd) '[s]'])
        end
    end
end

% Zeit als Spaltenvektor
t = (0:Tab:T)';

% Speicherplatz f�r Vektoren reservieren
y = zeros(size(t));

% Frequenzvektor logarithmisch stufen (Spaltenvektor)
f = logspace(log10(fStart),log10(fEnd),length(t))';

% Ausgangssignal ohne Schleife rechnen
y = sin( 2*pi*f.*t);

return;