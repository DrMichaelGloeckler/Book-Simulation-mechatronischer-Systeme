function [G,ampl,phase,freq]=sigbode(insignal,outsignal,tab,len,wndw)
%sigbode  compute the bode diagram from measured input and output signals
%         Bodediagramm f�r Eingangs- und Ausgangssignalfolge berechnen.
%
%   [G,ampl,phase,freq]=sigbode(insignal,outsignal,tab,len,wndw);
%
%   insignal  = Eingangssignalfolge
%   outsignal = Ausgangssignalfolge
%   tab       = sample time [s]
%               Abtastzeit [s]
%   len       = length of the fft sequence
%               L�nge der FFT [Abtastungen], s.a. fft.m
%   wndw      = window used in fft invocation, 
%               Fensterfunktion
%               wndw = 'hamming' || 'hanning' || 'none'; default = 'hamming'
%   G         = FFT(insignal) / FFT(outsignal)
%   ampl      = Amplitudengang [dB]
%   phase     = Phasengang [deg]
%   freq      = Frequenz [Hz]
%
%  See also hamming, hanning
%

%==========================================================================
% Prof. Dr.-Ing. Michael Gl�ckler
% Hochschule Augsburg
% Fakult�t f�r Maschinenbau und Verfahrenstechnik
% � 2009, 2011, 2014
%==========================================================================

%   -----------------------------------------------------------------------
% transform signal to column vectors if necessary
%   -----------------------------------------------------------------------
[nr,nc]=size(insignal);
if nr==1 && nc>1
    insignal = insignal';
elseif nr>1 && nc>1
    error('only vector allowed');
end
[nr,nc]=size(outsignal);
if nr==1 && nc>1
    outsignal = outsignal';
elseif nr>1 && nc>1
    error('only vector allowed');
end


%   -----------------------------------------------------------------------
%   FFT of input and output signal using hamming window
%   -----------------------------------------------------------------------
if strcmpi(wndw,'hamming')==1
    IN   = fft( hamming(length(insignal)).*insignal,len);
    OUT  = fft( hamming(length(outsignal)).*outsignal,len);
    
%   -----------------------------------------------------------------------
%   FFT of input and output signal using hanning window
%   -----------------------------------------------------------------------
elseif strcmpi(wndw,'hanning')==1
    IN   = fft( hanning(length(insignal)).*insignal,len);
    OUT  = fft( hanning(length(outsignal)).*outsignal,len);
    
%   -----------------------------------------------------------------------
%   FFT of input and output signal without window
%   -----------------------------------------------------------------------
else
    IN   = fft( insignal,len);
    OUT  = fft( outsignal,len);
end

%   -----------------------------------------------------------------------
% Frequency [Hz]
%   nur bis zur halben Abtastfrequenz wegen Abtasttheorem von Shannon
%   -----------------------------------------------------------------------
freq = (0:floor(len/2))/len/tab;    % (len/2+1) Frequenzen von 0 ... 1/tab [Hz]

%   -----------------------------------------------------------------------
% Frequenzgang 
%   -----------------------------------------------------------------------
G = OUT./IN;
ampl = ratio2dB(abs(G(1:length(freq))));     % Betrag
phase= 180/pi*angle(G(1:length(freq)));     % Phase

%   -----------------------------------------------------------------------
% Bodediagramm plotten
%   -----------------------------------------------------------------------
% figure;
% subplot(2,1,1); semilogx(freq,ampl(1:length(freq))); grid on;
% xlabel('f [Hz]'); ylabel('A [dB]');
% subplot(2,1,2); semilogx(freq,unwrap(phase(1:length(freq)))*180/pi); grid on;
% xlabel('f [Hz]'); ylabel('phi [deg]');

return;