function [db] = ratio2dB(ratio)
%ratio2dB   Umwandlung Verhaeltnis -> Dezibel
%
%	[db] = ratio2dB(ratio)
%
%	ratio = Verhaeltnis
%	db    = Verhaeltnis in [dB]
%
% s.a.: dB2ratio
%

nargs = nargin;

if (nargs==1),

  db = 20.0*log10(ratio);

else
  error('Wrong number of input arguments.');
end

return;